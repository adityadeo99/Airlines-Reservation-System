/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package admin_feedback;

import cancel_flight.*;
import CustomerBookingDetail.*;
import CustomerBookingDetail.*;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.ObservableList;

/**
 *
 * @author Akshay
 */
public class table {
 private final StringProperty id;
 private final StringProperty q1;
 private final StringProperty q2;
private final StringProperty q3;
private final StringProperty q4;
private final StringProperty q5;

    public table(String id, String name,String source3, String destination3,String departuret, String price) {
        this.id = new SimpleStringProperty(id);
        this.q1 = new SimpleStringProperty(name);
        this.q2 = new SimpleStringProperty(source3);
        this.q3 = new SimpleStringProperty(destination3);
        this.q4= new SimpleStringProperty(departuret);
        this.q5 = new SimpleStringProperty(price);
        
    }
public String getid() {
        return id.get();
    }
 public void setid(String value) {
         id.set(value);   
    }
  public StringProperty idProperty(){    return id;} 

    
    public String getq1() {
        return q1.get();
    }
      public void q1date(String value) {
         q1.set(value);   
    }
  public StringProperty q1Property(){    return q1;} 

    public String getq2() {
        return q2.get();
    }

      public void setq2(String value) {
         q2.set(value);   
    }
  public StringProperty q2Property(){    return q2;} 
  
  
  public String getq3() {
        return q3.get();
    }

      public void setq3(String value) {
         q3.set(value);   
    }
  public StringProperty q3Property(){    return q3;} 
  
  
   
   public String getq4() {
        return q4.get();
    }

      public void setq4(String value) {
         q4.set(value);   
    }
  public StringProperty q4Property(){    return q4;} 
   
   public String getq5() {
        return q5.get();
    }

      public void setq5(String value) {
         q5.set(value);   
    }
  public StringProperty q5Property(){    return q5;} 
}