/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package admin_feedback;

import static cancel_flight.FXMLDocumentController.trueid;

import commonpackage.ConnectionUtil;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 *
 * @author Aditya Deo
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    private TableColumn<table,String> cust_id;
    @FXML
    private TableColumn<table,String> q1;
    @FXML
    private TableColumn<table,String> q2;
    @FXML
    private TableColumn<table,String> q3;
    @FXML
    private TableColumn<table,String> q4;
    @FXML
    
    private TableColumn<table,String> q5;
     private ObservableList<table> data   ; 
    static public int trueid =UserLogin.FXMLController.retid();
       private ConnectionUtil dc;
    @FXML
    private TableView<table> table12;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        dc=new ConnectionUtil();
         Connection conn=dc.connectdb();
          data = FXCollections.observableArrayList();
           try{ 
            // String s12=datepik.getValue();
           ResultSet rs=conn.createStatement().executeQuery("select * from feedback");
                 
           System.out.print(rs);
          
            //System.out.println(rs);
           // rs.next();
            while(rs.next())
            {
                data.add(new table(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6)));
            }
           
            
                    }
          catch (SQLException ex) {
          System.out.println(ex);
          }
           cust_id.setCellValueFactory(new PropertyValueFactory<>("id"));
            q1.setCellValueFactory(new PropertyValueFactory<>("q1"));
             q2.setCellValueFactory(new PropertyValueFactory<>("q2"));
            q3.setCellValueFactory(new PropertyValueFactory<>("q3"));
            q4.setCellValueFactory(new PropertyValueFactory<>("q4"));
            q5.setCellValueFactory(new PropertyValueFactory<>("q5"));
                
           table12.setItems(data);
           System.out.println(table12);
        
        
        
        
    }    
    
}
