/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package searchflight;

import search_flight.*;
import com.jfoenix.controls.JFXComboBox;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author Aditya Deo
 */
public class FXMLDocumentController implements Initializable {
    
    private Label label;
    @FXML
    private AnchorPane one_way;
    @FXML
    private JFXComboBox source;
    @FXML
    private JFXComboBox destination;
      
   
    @FXML
    private TableColumn<table,String> id;
    @FXML
    private TableColumn<table,String> name;
    @FXML
    private TableColumn<table,String> source3;
    @FXML
    private TableColumn<table,String> destination3;
    @FXML
    private TableColumn<table,String> type;
    @FXML
    private TableColumn<table,String> arrivalt;
    @FXML
    private TableColumn<table,String> departuret;
    @FXML
    private TableColumn<table,String> price;
     @FXML
    private TableColumn<table,String> date;
     
      Connection connection = null;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;
    
      private ObservableList<table> data   ; 
    private ConnectionUtil dc;
    ObservableList<String> source1 =FXCollections.observableArrayList("Mumbai","Bangalore","Chennai","Pune","Hyderabad","New Delhi");
    ObservableList<String> destination2 =FXCollections.observableArrayList("Mumbai","Bangalore","Chennai","Pune","Hyderabad","New Delhi");
    ObservableList<String> genderlist =FXCollections.observableArrayList("Male","Female","Other");
    @FXML
    private TableView<table> tabale12;
    @FXML
    private DatePicker datepp;
   
     @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
       // load();
        dc=new ConnectionUtil();
          source.setItems(source1);
        datepp.setValue(LocalDate.now());
        destination.setItems(destination2);
    }    
    

    @FXML
    private void secLoad(MouseEvent event) throws Exception {
        AnchorPane pane = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
        one_way.getChildren().setAll(pane);
    }

    private void secondLoad(MouseEvent event)throws Exception {
        AnchorPane pane = FXMLLoader.load(getClass().getResource("round_trip.fxml"));
        one_way.getChildren().setAll(pane);
    }

    @FXML
    private void searchf(ActionEvent event) throws IOException {
          Connection conn=dc.connectdb();
          data = FXCollections.observableArrayList();
          
          String source22 ="",destination22="";
          source22=(String) source.getValue();
          destination22=(String) destination.getValue();
          

               if(!source22.equals(destination22)){
          try{ 
                     ResultSet rs=conn.createStatement().executeQuery("select * from fligtdetail where source='"+(source.getValue())+"' and destination='"+(destination.getValue())+"' ");
                     System.out.print(rs);
          
            while(rs.next())
            {
                data.add(new table(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(7),rs.getString(5),rs.getString(6),rs.getString(8)));
            }
             }
          catch (SQLException ex) {
          System.out.println(ex);
          }
           id.setCellValueFactory(new PropertyValueFactory<>("id"));
            name.setCellValueFactory(new PropertyValueFactory<>("name"));
             source3.setCellValueFactory(new PropertyValueFactory<>("source3"));
            destination3.setCellValueFactory(new PropertyValueFactory<>("destination3"));
             type.setCellValueFactory(new PropertyValueFactory<>("type"));
            price.setCellValueFactory(new PropertyValueFactory<>("price"));
             arrivalt.setCellValueFactory(new PropertyValueFactory<>("arrivalt"));
            departuret.setCellValueFactory(new PropertyValueFactory<>("departuret"));
           //  date.setCellValueFactory(new PropertyValueFactory<>("date"));
           // name.setCellValueFactory(new PropertyValueFactory<>("name"));
          
           tabale12.setItems(data);
           System.out.println(data);
           }else{
                  JFrame f = new JFrame(); 
               JOptionPane.showMessageDialog(f,"Entered Source & Destination Cannot Be Same ...","Alert",JOptionPane.INFORMATION_MESSAGE);   
               }
        /*
           else{
                JFrame f = new JFrame(); 
               JOptionPane.showMessageDialog(f,"Enter Source & Destination Before Searchng ...","Alert",JOptionPane.ERROR_MESSAGE);   
           }*/
    }
    
}
