/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package special_offers;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.animation.FadeTransition;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.RotateTransition;
import javafx.animation.ScaleTransition;
import javafx.animation.SequentialTransition;
import javafx.animation.Timeline;
import javafx.animation.TranslateTransition;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.image.ImageView;
import javafx.util.Duration;

/**
 *
 * @author Aditya Deo
 */
public class FXMLDocumentController implements Initializable {

    @FXML
    private ImageView img5;
    @FXML
    private ImageView img1;
    @FXML
    private ImageView img4;
    @FXML
    private ImageView img2;
    @FXML
    private ImageView img3;
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    /*   final Timeline timeline = new Timeline();
 timeline.setCycleCount(2);
 timeline.setAutoReverse(true);
 timeline.getKeyFrames().add(new KeyFrame(Duration.millis(5000),
   new KeyValue (img1.translateXProperty(), 50)));
 timeline.play();*/
    
    FadeTransition fadeTransition = 
            new FadeTransition(Duration.millis(1000), img1);
        fadeTransition.setFromValue(1.0f);
        fadeTransition.setToValue(0.3f);
        fadeTransition.setCycleCount(1);
        fadeTransition.setAutoReverse(true);
 
 
        ScaleTransition scaleTransition = 
            new ScaleTransition(Duration.millis(2000), img2);
        scaleTransition.setFromX(1);
        scaleTransition.setFromY(1);
        scaleTransition.setToX(2);
        scaleTransition.setToY(2);
        scaleTransition.setCycleCount(1);
        scaleTransition.setAutoReverse(true);
        
        FadeTransition fadeTransition1 = 
            new FadeTransition(Duration.millis(1000), img5);
        fadeTransition1.setFromValue(1.0f);
        fadeTransition1.setToValue(0.3f);
        fadeTransition1.setCycleCount(1);
        fadeTransition1.setAutoReverse(true);
 
 
        ScaleTransition scaleTransition1 = 
            new ScaleTransition(Duration.millis(2000), img4);
        scaleTransition1.setFromX(1);
        scaleTransition1.setFromY(1);
        scaleTransition1.setToX(1.5);
        scaleTransition1.setToY(1.5);
        scaleTransition1.setCycleCount(1);
        scaleTransition1.setAutoReverse(true);
        
        FadeTransition fadeTransition2 = 
            new FadeTransition(Duration.millis(1000), img2);
        fadeTransition2.setFromValue(1.0f);
        fadeTransition2.setToValue(0.3f);
        fadeTransition2.setCycleCount(1);
        fadeTransition2.setAutoReverse(true);
        
        FadeTransition fadeTransition3 = 
            new FadeTransition(Duration.millis(1000), img4);
        fadeTransition3.setFromValue(1.0f);
        fadeTransition3.setToValue(0.3f);
        fadeTransition3.setCycleCount(1);
        fadeTransition3.setAutoReverse(true);
        
        ScaleTransition scaleTransition2 = 
            new ScaleTransition(Duration.millis(2000), img3);
        scaleTransition2.setFromX(1);
        scaleTransition2.setFromY(1);
        scaleTransition2.setToX(2);
        scaleTransition2.setToY(2);
        scaleTransition2.setCycleCount(1);
        scaleTransition2.setAutoReverse(true);

SequentialTransition  sequentialTransition= new SequentialTransition();sequentialTransition.getChildren().addAll(fadeTransition,scaleTransition,fadeTransition1,scaleTransition1,fadeTransition2,fadeTransition3,scaleTransition2);
sequentialTransition.setCycleCount(2);
sequentialTransition.setAutoReverse(true);
sequentialTransition.play();
    }    
    
}
