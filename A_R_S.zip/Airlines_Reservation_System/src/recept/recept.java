/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package recept;

import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.geometry.Rectangle2D;
import javafx.stage.Screen;
import UserLogin.FXMLController;

/**
 *
 * @author mahesh
 */
public class recept extends Application {

    public static int trueid =FXMLController.retid();

    public static int recept1() {
      System.out.println(trueid);
        return (trueid);
    }
  

    
    
    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("FXML.fxml"));
        
        Scene scene = new Scene(root);
    
       
       stage.setScene(scene);
       
       Rectangle2D primaryScreenBounds = Screen.getPrimary().getVisualBounds();

        //set Stage boundaries to visible bounds of the main screen
        stage.setX(primaryScreenBounds.getMinX());
        stage.setY(primaryScreenBounds.getMinY());
        stage.setWidth(primaryScreenBounds.getWidth());
        stage.setHeight(primaryScreenBounds.getHeight());
       
       stage.show();
       
       
    }

    /**
     * @param args the command line arguments
     */
   
    public static void main(String[] args) {
        
        launch(args);
    }

   
    
}
