/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package recept;

import java.io.IOException;
import UserLogin.FXMLController;
import com.jfoenix.controls.JFXTextField;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;

/**
 *
 * @author mahesh
 */
public class receptController implements Initializable {
    
    
    
    @FXML
    private Label nameL;

    @FXML
    private Label fromL;

    @FXML
    private Label toL;

    @FXML
    private Label gateL;

    @FXML
    private Label timeL;

    @FXML
    private Label flightL;

    @FXML
    private Label dateL;

    @FXML
    private Label boardingtillL;

    @FXML
    private Label seatL;

  static public int trueid ;
 
   static public int retidk()
   {
   return trueid;
   }
   
   // public receptController(){    }
    @FXML
    private Label seatL1;
    @FXML
    private Label nameL1;
    @FXML
    private Label fromL1;
    @FXML
    private Label toL1;
    @FXML
    private Label timeL1;
    @FXML
    private Label flightL1;
    @FXML
    private Label dateL1;
    @FXML
    private Label gateL1;
    @FXML
    private Label boardingtillL1;
    private JFXTextField id;
    @FXML
    private JFXTextField id1;
   
    
     @Override
    public void initialize(URL url, ResourceBundle rb) {
         
         trueid =FXMLController.retid();
        
    }

    @FXML
    private void searcht(ActionEvent event) {
        
         try{
            
            String driver="com.mysql.jdbc.Driver";
            String url1="jdbc:mysql://localhost:3306/swingapp";
            String username="root";
            String password="";
            Class.forName(driver);
            
            Connection conn= DriverManager.getConnection(url1,username,password);
            System.out.println("Connected");
            System.out.println(trueid);
            Statement st=conn.createStatement();
            Statement st1=conn.createStatement();
            
            ResultSet rs=st.executeQuery("select * from customerdetail where id="+trueid);
             ResultSet rs1=st1.executeQuery("SELECT * FROM `bookingdetails` WHERE userid='"+trueid+"'&&flightid='"+id1.getText()+"'");
            
            System.out.print(rs1);
            rs1.next();
               seatL1.setText((rs1.getString(11)));
               fromL1.setText((rs1.getString(3)));
               toL1.setText((rs1.getString(4)));
               timeL1.setText((rs1.getString(7)));
               flightL1.setText((rs1.getString(6)));
               dateL1.setText((rs1.getString(9)));
               seatL.setText((rs1.getString(11)));
               fromL.setText((rs1.getString(3)));
               toL.setText((rs1.getString(4)));
               timeL.setText((rs1.getString(7)));
               flightL.setText((rs1.getString(6)));
               dateL.setText((rs1.getString(9)));
                 nameL.setText((rs1.getString(10)));
            nameL1.setText((rs1.getString(10)));
                
            
            while (rs.next())
            {
            System.out.print(rs);
            }
            
        
        } catch (SQLException ex) {
            Logger.getLogger(receptController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(receptController.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        
    }    

    
  
    
    }
       
    
     
     
      
      //for recept change purpose
      
      
      
      

