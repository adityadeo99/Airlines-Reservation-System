/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dashboard2;

import UserLogin.FXMLController;
import animatefx.animation.Shake;
import animatefx.animation.ZoomIn;
import com.jfoenix.controls.JFXButton;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Duration;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
/**
 *
 * @author mahesh
 */
public class FXMLDocumentController implements Initializable {
    
static public int User =UserLogin.FXMLController.retid();
       Stage dialogStage = new Stage();
       int flag=0;
        Connection connection = null;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;
        
    @FXML
    private AnchorPane dashboard;
    @FXML
    private JFXButton dashboard1;
    @FXML
    private JFXButton updatedetail;
    @FXML
    private JFXButton searchflight;
    @FXML
    private JFXButton bookflight;
    @FXML
    private JFXButton cancelflight;
    @FXML
    private JFXButton viewbookf;
    @FXML
    private JFXButton reciptf;
    @FXML
    private JFXButton feedback;
    @FXML
    private JFXButton faqs;
 
    @FXML
    private AnchorPane box1;
    @FXML
    private AnchorPane box2;
    @FXML
    private AnchorPane box3;
    @FXML
    private AnchorPane anch;
    @FXML
    private Label text;
             static public String name;     
    @FXML
    private Label nameid;
      @Override
    public void initialize(URL url, ResourceBundle rb) {
       name=FXMLController.retname();
            nameid.setText(name);
 /*   
    try {
        String Sql1="select * from customerdetail where id ='"+User+"' ";
        preparedStatement = connection.prepareStatement(Sql1);
           resultSet = preparedStatement.executeQuery();
           if(resultSet.next())
        {
            String fname=resultSet.getString("firstname");
            String lname=resultSet.getString("lastname");
           text.setText(fname+" "+lname);
                    }
    } catch (SQLException ex) {
        Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
    }
 */  
       TranslateTransition t = new TranslateTransition();
      t.setDuration(Duration.seconds(1));
      //t.setAutoReverse(true);
      t.setCycleCount(2);
      t.setToX(670); t.setNode(box1); t.play();
      
       TranslateTransition t1 = new TranslateTransition();
      t1.setDuration(Duration.seconds(1));
     // t1.setAutoReverse(true);
      t1.setCycleCount(2);
    //  t1.setToX(-300);
      t1.setNode(box2); t1.play();
      
       TranslateTransition t2 = new TranslateTransition();
      t2.setDuration(Duration.seconds(1));
     // t1.setAutoReverse(true);
      t2.setCycleCount(2);
      t2.setToX(-670); t2.setNode(box3); t2.play();
      

    }    
     @FXML
    private void dashboardf(ActionEvent event) throws IOException {
       AnchorPane pane = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
        anch.getChildren().setAll(pane);
         new ZoomIn(anch).play();
         new Shake(dashboard1).play();
     
     dashboard1.setStyle("-fx-background-color:#162585;");
       updatedetail.setStyle("-fx-background-color:#7C4DFF;"); 
       searchflight.setStyle("-fx-background-color:#7C4DFF;"); 
       bookflight.setStyle("-fx-background-color:#7C4DFF;");
       cancelflight.setStyle("-fx-background-color:#7C4DFF;");
       viewbookf.setStyle("-fx-background-color:#7C4DFF;");
       reciptf.setStyle("-fx-background-color:#7C4DFF;");
       feedback.setStyle("-fx-background-color:#7C4DFF;");
       faqs.setStyle("-fx-background-color:#7C4DFF;");
       
    }
    @FXML
     private void updatef(ActionEvent event) throws IOException {
       dashboard1.setStyle("-fx-background-color:#7C4DFF;");
       updatedetail.setStyle("-fx-background-color:#162585;"); 
       searchflight.setStyle("-fx-background-color:#7C4DFF;"); 
       bookflight.setStyle("-fx-background-color:#7C4DFF;");
       cancelflight.setStyle("-fx-background-color:#7C4DFF;");
       viewbookf.setStyle("-fx-background-color:#7C4DFF;");
       reciptf.setStyle("-fx-background-color:#7C4DFF;");
       feedback.setStyle("-fx-background-color:#7C4DFF;");
       faqs.setStyle("-fx-background-color:#7C4DFF;");
       AnchorPane pane = FXMLLoader.load(getClass().getResource("/cust_update/FXMLDocument.fxml"));
        dashboard.getChildren().setAll(pane);
         new ZoomIn(dashboard).play();
     new Shake(updatedetail).play();
    }
      @FXML
     private void searchf(ActionEvent event) throws IOException {
         dashboard1.setStyle("-fx-background-color:#7C4DFF;");
       updatedetail.setStyle("-fx-background-color:#7C4DFF;"); 
       searchflight.setStyle("-fx-background-color:#162585;"); 
       bookflight.setStyle("-fx-background-color:#7C4DFF;");
       cancelflight.setStyle("-fx-background-color:#7C4DFF;");
       viewbookf.setStyle("-fx-background-color:#7C4DFF;");
       reciptf.setStyle("-fx-background-color:#7C4DFF;");
       feedback.setStyle("-fx-background-color:#7C4DFF;");
       faqs.setStyle("-fx-background-color:#7C4DFF;");
       
       AnchorPane pane = FXMLLoader.load(getClass().getResource("/searchflight/FXMLDocument.fxml"));
        dashboard.getChildren().setAll(pane);
         new ZoomIn(dashboard).play();
     new Shake(searchflight).play();
    }
       @FXML
     private void bookf(ActionEvent event) throws IOException {
          dashboard1.setStyle("-fx-background-color:#7C4DFF;");
       updatedetail.setStyle("-fx-background-color:#7C4DFF;"); 
       searchflight.setStyle("-fx-background-color:#7C4DFF;"); 
       bookflight.setStyle("-fx-background-color:#162585;");
       cancelflight.setStyle("-fx-background-color:#7C4DFF;");
       viewbookf.setStyle("-fx-background-color:#7C4DFF;");
       reciptf.setStyle("-fx-background-color:#7C4DFF;");
       feedback.setStyle("-fx-background-color:#7C4DFF;");
       faqs.setStyle("-fx-background-color:#7C4DFF;");
       
       AnchorPane pane = FXMLLoader.load(getClass().getResource("/BookTicketcustomer/FXML.fxml"));
        dashboard.getChildren().setAll(pane);
        new ZoomIn(dashboard).play();
     new Shake(bookflight).play();
    }
       @FXML
     private void cancelf(ActionEvent event) throws IOException {
       dashboard1.setStyle("-fx-background-color:#7C4DFF;");
       updatedetail.setStyle("-fx-background-color:#7C4DFF;"); 
       searchflight.setStyle("-fx-background-color:#7C4DFF;"); 
       bookflight.setStyle("-fx-background-color:#7C4DFF;");
       cancelflight.setStyle("-fx-background-color:#162585;");
       viewbookf.setStyle("-fx-background-color:#7C4DFF;");
       reciptf.setStyle("-fx-background-color:#7C4DFF;");
       feedback.setStyle("-fx-background-color:#7C4DFF;");
       faqs.setStyle("-fx-background-color:#7C4DFF;");
         
       AnchorPane pane = FXMLLoader.load(getClass().getResource("/cancel_flight/FXMLDocument.fxml"));
        dashboard.getChildren().setAll(pane);
         new ZoomIn(dashboard).play();
     new Shake(cancelflight).play();
    }

       @FXML
     private void viewbf(ActionEvent event) throws IOException {
       dashboard1.setStyle("-fx-background-color:#7C4DFF;");
       updatedetail.setStyle("-fx-background-color:#7C4DFF;"); 
       searchflight.setStyle("-fx-background-color:#7C4DFF;"); 
       bookflight.setStyle("-fx-background-color:#7C4DFF;");
       cancelflight.setStyle("-fx-background-color:#7C4DFF;");
       viewbookf.setStyle("-fx-background-color:#162585;");
       reciptf.setStyle("-fx-background-color:#7C4DFF;");
       feedback.setStyle("-fx-background-color:#7C4DFF;");
       faqs.setStyle("-fx-background-color:#7C4DFF;");
       AnchorPane pane = FXMLLoader.load(getClass().getResource("/CustomerBookingDetail/FXML.fxml"));
        dashboard.getChildren().setAll(pane);
         new ZoomIn(dashboard).play();
     new Shake(viewbookf).play();
    }

       @FXML
     private void reciptf(ActionEvent event) throws IOException {
       dashboard1.setStyle("-fx-background-color:#7C4DFF;");
       updatedetail.setStyle("-fx-background-color:#7C4DFF;"); 
       searchflight.setStyle("-fx-background-color:#7C4DFF;"); 
       bookflight.setStyle("-fx-background-color:#7C4DFF;");
       cancelflight.setStyle("-fx-background-color:#7C4DFF;");
       viewbookf.setStyle("-fx-background-color:#7C4DFF;");
       reciptf.setStyle("-fx-background-color:#162585;");
       feedback.setStyle("-fx-background-color:#7C4DFF;");
       faqs.setStyle("-fx-background-color:#7C4DFF;");
       AnchorPane pane = FXMLLoader.load(getClass().getResource("/recept/FXML.fxml"));
        dashboard.getChildren().setAll(pane);
             new Shake(reciptf).play();

    }

       @FXML
     private void feedbackf(ActionEvent event) throws IOException {
       dashboard1.setStyle("-fx-background-color:#7C4DFF;");
       updatedetail.setStyle("-fx-background-color:#7C4DFF;"); 
       searchflight.setStyle("-fx-background-color:#7C4DFF;"); 
       bookflight.setStyle("-fx-background-color:#7C4DFF;");
       cancelflight.setStyle("-fx-background-color:#7C4DFF;");
       viewbookf.setStyle("-fx-background-color:#7C4DFF;");
       reciptf.setStyle("-fx-background-color:#7C4DFF;");
       feedback.setStyle("-fx-background-color:#162585;");
       faqs.setStyle("-fx-background-color:#7C4DFF;");
       AnchorPane pane = FXMLLoader.load(getClass().getResource("/feedback_2/FXMLDocument.fxml"));
        dashboard.getChildren().setAll(pane);
         new ZoomIn(dashboard).play();
     new Shake(feedback).play();
    }

       @FXML
     private void faqsf(ActionEvent event) throws IOException {
       dashboard1.setStyle("-fx-background-color:#7C4DFF;");
       updatedetail.setStyle("-fx-background-color:#7C4DFF;"); 
       searchflight.setStyle("-fx-background-color:#7C4DFF;"); 
       bookflight.setStyle("-fx-background-color:#7C4DFF;");
       cancelflight.setStyle("-fx-background-color:#7C4DFF;");
       viewbookf.setStyle("-fx-background-color:#7C4DFF;");
       reciptf.setStyle("-fx-background-color:#7C4DFF;");
       feedback.setStyle("-fx-background-color:#7C4DFF;");
       faqs.setStyle("-fx-background-color:#162585;");
       
       AnchorPane pane = FXMLLoader.load(getClass().getResource("/faqs/FXMLDocument.fxml"));
        dashboard.getChildren().setAll(pane);
         new ZoomIn(dashboard).play();
     new Shake(faqs).play();
    }
       @FXML
     private void logoutf(ActionEvent event) throws IOException {
       Node node = (Node)event.getSource();
                dialogStage = (Stage) node.getScene().getWindow();
                dialogStage.close();
               
           Scene  scene = new Scene(FXMLLoader.load(getClass().getResource("/home/FXMLDocument.fxml")));
                
                dialogStage.setScene(scene);
        
                dialogStage.show();
               //  dialogStage.close();
                
                
    }
/*
    @FXML
     private void play(ActionEvent event) throws IOException {
        //MediaPlayer player = new MediaPlayer( new Media(getClass().getResource("/media/Motion.mp4").toExternalForm()));
        //media.setMediaPlayer(player);

        //dashboard.getChildren().add( media);
        //player.play();
        
        String path= "/media/Motion.mp4";
        Media me = new Media(new File(path).toURI().toString());
        MediaPlayer mp= new MediaPlayer(me);
        media.setMediaPlayer(mp);
        
       // mp.setCycleCount(javafx.scene.media.MediaPlayer.INDEFINITE);
       // mp.play();
        mp.setAutoPlay(true);  
        dashboard.getChildren().add(media);
     }*/
   
    
}
