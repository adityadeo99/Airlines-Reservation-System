/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package feedback_2;

import com.jfoenix.controls.JFXRadioButton;
import commonpackage.ConnectionUtil;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.AnchorPane;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author Aditya Deo
 */
public class FXMLDocumentController implements Initializable {
    
    private Label label;
    @FXML
    private JFXRadioButton a2;
    @FXML
    private JFXRadioButton a1;
    @FXML
    private JFXRadioButton a3;
    @FXML
    private JFXRadioButton a4;
    @FXML
    private JFXRadioButton b2;
    @FXML
    private JFXRadioButton b1;
    @FXML
    private JFXRadioButton b3;
    @FXML
    private JFXRadioButton b4;
    @FXML
    private JFXRadioButton c2;
    @FXML
    private JFXRadioButton c1;
    @FXML
    private JFXRadioButton c3;
    @FXML
    private JFXRadioButton c4;
    @FXML
    private JFXRadioButton d2;
    @FXML
    private JFXRadioButton d1;
    @FXML
    private JFXRadioButton d3;
    @FXML
    private JFXRadioButton d4;
    @FXML
    private JFXRadioButton e2;
    @FXML
    private JFXRadioButton e1;
    @FXML
    private JFXRadioButton e3;
    @FXML
    private JFXRadioButton e4;
    @FXML
    private ToggleGroup groupA;
    @FXML
    private ToggleGroup groupB;
    @FXML
    private ToggleGroup groupC;
    @FXML
    private ToggleGroup groupD;
    @FXML
    private ToggleGroup groupE;
    @FXML
    private Button submit;
    Connection connection = null;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;
    @FXML
    private AnchorPane anchor1;
    
 static public int trueid =UserLogin.FXMLController.retid();

    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }    
    
     @FXML
    private void submitDone(ActionEvent event) throws SQLException, IOException {
           
         connection = ConnectionUtil.connectdb();
       //  String id="asd";
         RadioButton srm = (RadioButton) groupA.getSelectedToggle();
         String ans1 = srm.getText();
         RadioButton srm1 = (RadioButton) groupB.getSelectedToggle();
         String ans2 = srm1.getText();
         RadioButton srm2 = (RadioButton) groupC.getSelectedToggle();
         String ans3 = srm2.getText();
         RadioButton srm3 = (RadioButton) groupD.getSelectedToggle();
         String ans4 = srm3.getText();
         RadioButton srm4 = (RadioButton) groupE.getSelectedToggle();
         String ans5 = srm4.getText();
         
       /*  boolean i1 = ans1.isEmpty();
         boolean i2 = ans2.isEmpty();
         boolean i3 = ans3.isEmpty();
         boolean i4 = ans4.isEmpty();
         boolean i5 = ans5.isEmpty();
         
        if(!i1)
         {*/
         String sql="insert into feedback values('"+trueid+"','"+ans1+"','"+ans2+"','"+ans3+"','"+ans4+"','"+ans5+"')";
          preparedStatement = connection.prepareStatement(sql);
        preparedStatement.executeUpdate();
         
        JFrame f; 
                    f=new JFrame(); 
                                 JOptionPane.showMessageDialog(f,"Your Feedback Has Been Submitted  Successfully !!!","Alert",JOptionPane.OK_OPTION);        
                                 
         AnchorPane pane=FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
    anchor1.getChildren().setAll(pane);                        
      /*   }
        else{
             JFrame f = new JFrame(); 
               JOptionPane.showMessageDialog(f,"Please Give FeedBack for All the Questions ...","Alert",JOptionPane.ERROR_MESSAGE); 
         }*/
    }
}
