/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Forgetp;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import commonpackage.ConnectionUtil;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author Akshay
 */
public class FXMLController implements Initializable {

    Stage dialogStage = new Stage();
    Scene scene;
    Scene scene1;
        Connection connection = null;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;
    @FXML 
      private JFXTextField user;
    @FXML
    private JFXPasswordField pass1;
    @FXML
    private JFXPasswordField pass2;
    @FXML
    private JFXButton Done;
    @FXML
    private AnchorPane anchor1;
    
     @FXML
    private void homeff(ActionEvent event) throws IOException, SQLException {
         
         connection = ConnectionUtil.connectdb();
         String User=user.getText();
         String p1=pass1.getText();
         String p2=pass2.getText();
         int i1 = user.getText().length();
         int i2 = pass1.getText().length();
         int i3 = pass2.getText().length();
        
         if(i1>0&&i2>0&&i3>0){
         String Sql1="select * from customer where username ='"+user.getText()+"' ";
          preparedStatement = connection.prepareStatement(Sql1);
           // preparedStatement.setString(1,User);
            resultSet = preparedStatement.executeQuery();
         if(resultSet.next())
         {
             String username=resultSet.getString("username");
             if(User.equals(username))
             {  
                 if(p1.equals(p2)){
                  String sql="update customer set password='"+pass1.getText()+"' where username='"+User+"'";
          Statement smt3=connection.createStatement();
                    //ResultSet   rs=smt3.executeQueryUpdate(query);

                       int success=smt3.executeUpdate(sql);
                       if(success==1){
                           JFrame f; 
                             f=new JFrame(); 
                                 JOptionPane.showMessageDialog(f," Your Password has been Successfully Updated ...","Alert",JOptionPane.OK_OPTION);  
                       }
                 } 
                 else{
                      JFrame f=new JFrame(); 
                                 JOptionPane.showMessageDialog(f,"Both Passwords doesn't match...","Alert",JOptionPane.OK_OPTION);  
                 }
             } else{
                                JFrame f; 
                                f=new JFrame(); 
                                 JOptionPane.showMessageDialog(f,"Username Does not Exist...\nFirst Register Yourself !! ...","Alert",JOptionPane.ERROR_MESSAGE); 
                            
             }
        
        Node node = (Node)event.getSource();
                dialogStage = (Stage) node.getScene().getWindow();
                dialogStage.close();
                scene = new Scene(FXMLLoader.load(getClass().getResource("/home/FXMLDocument.fxml")));  
                dialogStage.setScene(scene);
                dialogStage.show();
                dialogStage.close();
         }      
         }
         else {
                            JFrame f=new JFrame(); 
                            JOptionPane.showMessageDialog(f," Fields Cannot be Empty ...","Alert",JOptionPane.ERROR_MESSAGE); 
         }
                
    }
    
    @FXML
     private void adminLogin(ActionEvent event) throws IOException {
        AnchorPane pane = FXMLLoader.load(getClass().getResource("admin.fxml"));
        anchor1.getChildren().setAll(pane);
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
