/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BookTicketcustomer;
import recept.recept;
import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TreeTableColumn;
import javafx.scene.control.TreeTableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import recept.recept;
import search_flight.ConnectionUtil;
import BookTicketcustomer.seatController;
import java.time.LocalDate;
import javafx.stage.Modality;

/**
 * FXML Controller class
 *
 * @author Akshay
 */
public class FXMLController implements Initializable {

    static public int trueid =recept.recept1();

    static void done() {
        
    }

    
    
     
    @FXML
    private JFXTextField cname;
    @FXML
    private JFXTextField fname;
    @FXML
    private ComboBox gender;
    @FXML
    private JFXTextField fid;
    @FXML
    public JFXButton bookf;
    @FXML
    private TableColumn<table,String> id;
    @FXML
    private TableColumn<table,String> name;
    @FXML
    private TableColumn<table,String> source3;
    @FXML
    private TableColumn<table,String> destination3;
    @FXML
    private TableColumn<table,String> departuret;
    @FXML
    private TableColumn<table,String> arrivalt;
    @FXML
    private TableColumn<table,String> type;
    @FXML
    private TableColumn<table,String> price;
    @FXML
    private DatePicker datepp;
    @FXML
    private JFXButton searchf;
      
    Connection connection = null;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;
   
    Stage dialogStage = new Stage();
    Stage dialogStage1 = new Stage();
    Scene scene;
    @FXML
    private JFXTextField passportno;
    @FXML
    private ComboBox source;
    @FXML
    private ComboBox destination;
 ObservableList<String> source1 =FXCollections.observableArrayList("Mumbai","Bangalore","Chennai","Pune","Hyderabad","New Delhi");
    ObservableList<String> destination2 =FXCollections.observableArrayList("Mumbai","Bangalore","Chennai","Pune","Hyderabad","New Delhi");
    ObservableList<String> genderlist =FXCollections.observableArrayList("Male","Female","Other");
    @FXML
    private TableView<table> table12;
    private TableColumn<table,String> date;
    
    private ObservableList<table> data   ; 
    private ConnectionUtil dc;
    @FXML
    private JFXButton bookf2;
    @FXML
    private JFXButton Payment;
    
        
  
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        
        bookf.visibleProperty().setValue(Boolean.FALSE);
        dc=new ConnectionUtil();
        source.setItems(source1);
        datepp.setValue(LocalDate.now());
        destination.setItems(destination2);
        gender.setValue("Male");
    gender.setItems(genderlist);
    
    System.out.println(trueid);
    

    }
    
     

    @FXML
    private void searchf(ActionEvent event) throws IOException {
          Connection conn=dc.connectdb();
          data = FXCollections.observableArrayList();
          
          String source22 ="",destination22="";
          source22=(String) source.getValue();
          destination22=(String) destination.getValue();
          

               if(!source22.equals(destination22)){
          try{ 
                     ResultSet rs=conn.createStatement().executeQuery("select * from fligtdetail where source='"+(source.getValue())+"' and destination='"+(destination.getValue())+"' ");
                     System.out.print(rs);
          
            while(rs.next())
            {
                data.add(new table(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(7),rs.getString(5),rs.getString(6),rs.getString(8)));
            }
             }
          catch (SQLException ex) {
          System.out.println(ex);
          }
           id.setCellValueFactory(new PropertyValueFactory<>("id"));
            name.setCellValueFactory(new PropertyValueFactory<>("name"));
             source3.setCellValueFactory(new PropertyValueFactory<>("source3"));
            destination3.setCellValueFactory(new PropertyValueFactory<>("destination3"));
             type.setCellValueFactory(new PropertyValueFactory<>("type"));
            price.setCellValueFactory(new PropertyValueFactory<>("price"));
             arrivalt.setCellValueFactory(new PropertyValueFactory<>("arrivalt"));
            departuret.setCellValueFactory(new PropertyValueFactory<>("departuret"));
           //  date.setCellValueFactory(new PropertyValueFactory<>("date"));
           // name.setCellValueFactory(new PropertyValueFactory<>("name"));
          
           table12.setItems(data);
           System.out.println(data);
           }else{
                  JFrame f = new JFrame(); 
               JOptionPane.showMessageDialog(f,"Entered Source & Destination Cannot Be Same ...","Alert",JOptionPane.ERROR_MESSAGE);   
               }
        /*
           else{
                JFrame f = new JFrame(); 
               JOptionPane.showMessageDialog(f,"Enter Source & Destination Before Searchng ...","Alert",JOptionPane.ERROR_MESSAGE);   
           }*/
    }

    @FXML
    private void bookff(ActionEvent event) throws SQLException, IOException {
        
        
        String seatnodata=seatController.confirmaction();
        String sqli="select * from fligtdetail where flightid="+fid.getText();
        System.out.println(fid.getText());
        Connection conn=dc.connectdb();
        
        try {
            ResultSet resultSet=conn.createStatement().executeQuery(sqli);
            
            
            resultSet.next();
        System.out.println(resultSet.getString(3));
        System.out.println(resultSet.getString(4));
                          LocalDate myDate = datepp.getValue();

                          
          String maind="insert into bookingdetails values("+trueid+","+fid.getText()+",'"+resultSet.getString(3)+"','"+resultSet.getString(4)+"','"+resultSet.getString(5)+"','"+resultSet.getString(7)+"','"+resultSet.getString(6)+"','"+resultSet.getString(8)+"','"+myDate
              +"','"+cname.getText()+"','"+seatnodata+"','"+gender.getValue()+"','"+passportno.getText()+"','"+"45456"+"')";
        
     // String timepass=
      System.out.println(maind);
          conn.createStatement().executeUpdate(maind);

         
        } catch (SQLException ex) {
            Logger.getLogger(FXMLController.class.getName()).log(Level.SEVERE, null, ex);
        }
       
        
        JFrame f1; 
                    f1=new JFrame();  
                        JOptionPane.showMessageDialog(f1," Booking Successful.","Alert",JOptionPane.YES_OPTION);                     
                
       
    }

    @FXML
    private void bookff2(ActionEvent event) throws IOException {
        
         Node node = (Node)event.getSource();
                //dialogStage = (Stage) node.getScene().getWindow();
                dialogStage.close();
                
                scene = new Scene(FXMLLoader.load(getClass().getResource("seat.fxml")));
                
               dialogStage.setScene(scene);
                dialogStage.show();
              
    }

    @FXML
    private void Paymentff(ActionEvent event) throws IOException {
        
        
                 bookf.visibleProperty().setValue(Boolean.TRUE);
              /*
                 Node node = (Node)event.getSource();
                dialogStage1 = (Stage) node.getScene().getWindow();
                //dialogStage.close();
                scene = new Scene(FXMLLoader.load(getClass().getResource("/Payment/payment.fxml")));
                //scene.getPrimary();

               dialogStage.setScene(scene);
               
               dialogStage.initModality(Modality.APPLICATION_MODAL);
                dialogStage.initOwner(dialogStage1.getScene().getWindow());
                dialogStage.show();
                */
                
               Node node = (Node)event.getSource();
                dialogStage.close();
                scene = new Scene(FXMLLoader.load(getClass().getResource("/Payment/payment.fxml")));
               dialogStage.setScene(scene);
               dialogStage.show();
 
    }
    
    
}
