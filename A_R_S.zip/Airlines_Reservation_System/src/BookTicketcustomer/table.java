/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BookTicketcustomer;

import search_flight.*;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.ObservableList;

/**
 *
 * @author Akshay
 */
public class table {
 private final StringProperty id;
 private final StringProperty name;
 private final StringProperty source3;
private final StringProperty destination3;
private final StringProperty type;
private final StringProperty arrivalt;
private final StringProperty departuret;
private final StringProperty price;
//private final StringProperty date;

    public table(String id, String name,String source3, String destination3,String type, String arrivalt,String departuret, String price) {
        this.id = new SimpleStringProperty(id);
        this.name = new SimpleStringProperty(name);
        this.source3 = new SimpleStringProperty(source3);
        this.destination3 = new SimpleStringProperty(destination3);
        this.type = new SimpleStringProperty(type);
        this.arrivalt = new SimpleStringProperty(arrivalt);
        this.departuret = new SimpleStringProperty(departuret);
        this.price = new SimpleStringProperty(price);
      //  this.date=new SimpleStringProperty(date);
    }
/*
    public String getdate() {
        return date.get();
    }
      public void setdate(String value) {
         date.set(value);   
    }
  public StringProperty dateProperty(){    return date;} 
*/
    public String getid() {
        return id.get();
    }

      public void setid(String value) {
         id.set(value);   
    }
  public StringProperty idProperty(){    return id;} 
   
  public String getname() {
        return name.get();
    }
 public void setname(String value) {
         name.set(value);   
    }
  public StringProperty nameProperty(){    return name;}
  
    public String getsource3() {
        return source3.get();
    }
 public void setsource3(String value) {
         source3.set(value);   
    }
  public StringProperty source3Property(){    return source3;} 
    
    
    
    public String getDestination3() {
        return destination3.get();
    }
     public void setdestination3(String value) {
         destination3.set(value);   
    }
  public StringProperty destination3Property(){    return destination3;} 

    
    public String getType() {
        return type.get();
    }
    
     public void settype(String value) {
         type.set(value);   
    }
  public StringProperty typeProperty(){    return type;} 

    public String getArrivalt() {
        return arrivalt.get();
    }
     public void setarrivalt(String value) {
         arrivalt.set(value);   
    }
  public StringProperty arrivaltProperty(){    return arrivalt;} 

    public String getDeparturet() {
        return departuret.get();
    }
    
     public void setdeparturet(String value) {
         departuret.set(value);   
    }
  public StringProperty departuretProperty(){    return departuret;} 

    public String getPrice() {
        return price.get();
    }

       public void setprice(String value) {
         price.set(value);   
    }
  public StringProperty priceProperty(){    return price;} 

    
}
  


