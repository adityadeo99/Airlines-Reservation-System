/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package BookTicketcustomer;

import com.jfoenix.controls.JFXButton;
import static java.awt.Color.RED;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.paint.Color;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import BookTicketcustomer.FXMLController;
import javafx.scene.control.Label;
/**
 *
 * @author mahesh
 */
public class seatController {


    static String confirmaction()
    {
        return rect;
    }
    @FXML
    private Label seatnoL;
    @FXML
    private Rectangle C1;
    @FXML
    private Rectangle D2;
    @FXML
    private Rectangle A1;
    @FXML
    private Rectangle A2;
    @FXML
    private Rectangle B4;
    @FXML
    private Rectangle A5;
    @FXML
    private Rectangle A6;
    @FXML
    private Rectangle D6;
    @FXML
    private Rectangle D7;
    @FXML
    private Rectangle A7;
    @FXML
    private Rectangle F14;
    @FXML
    private Rectangle F16;
    @FXML
    private Rectangle F18;
    @FXML
    private Rectangle F20;
    @FXML
    private Rectangle F22;
    @FXML
    private Rectangle F24;
    @FXML
    private Rectangle D23;
    @FXML
    private Rectangle D25;
    @FXML
    private Rectangle E24;
    @FXML
    private Rectangle E26;
    @FXML
    private Rectangle E15;
    @FXML
    private Rectangle E17;
    @FXML
    private Rectangle D15;
    @FXML
    private Rectangle D17;
    @FXML
    private Rectangle A15;
    @FXML
    private Rectangle A17;
    @FXML
    private Rectangle A20;
    @FXML
    private Rectangle A22;
    @FXML
    private Rectangle B20;
    @FXML
    private Rectangle B22;
    @FXML
    private Rectangle B25;
    @FXML
    private Rectangle B27;
    @FXML
    private Rectangle A24;
    @FXML
    private Rectangle A26;
    @FXML
    private Rectangle F27;
    @FXML
    private Rectangle E27;
    @FXML
    private Rectangle D27;
    @FXML
    private Rectangle A27;
    @FXML
    private Rectangle E13;
    @FXML
    private Rectangle D13;
    @FXML
    private Rectangle B12;
    @FXML
    private Rectangle A12;
    @FXML
    private Rectangle F10;
    @FXML
    private Rectangle E10;
    @FXML
    private Rectangle D10;
    @FXML
    private Rectangle F9;
    @FXML
    private Rectangle E9;
    @FXML
    private Rectangle D9;
    @FXML
    private Rectangle C9;
    @FXML
    private Rectangle B9;
    @FXML
    private Rectangle A9;
    @FXML
    private Rectangle C10;
    @FXML
    private Rectangle B10;
    @FXML
    private Rectangle A10;
    @FXML
    private Rectangle E12;
    @FXML
    private Rectangle B13;
    @FXML
    private Rectangle B18;
    @FXML
    private Rectangle A19;
    @FXML
    private Rectangle E20;
    @FXML
    private Rectangle D22;

    public static String rect;
    public int one=0;
    public int p=1;
    @FXML
    private JFXButton confirmf;
    
    Stage dialogStage = new Stage();
    Scene scene;
    
    @FXML
    private void seatclicked(MouseEvent event) {
        
       Rectangle rec=(Rectangle) event.getSource(); 
       rect=rec.getId();
       
       System.out.println(rect);
       if(one==0){
 
           if(p==1){
       rec.setFill(Color.DARKBLUE);
       one=1;
       }
       }
       else if(one==1){ 
       if(p==2){
       rec.setFill(Color.GREEN);
       one=0;
       }
       }
       else 
       {
           System.out.println("you can only select one at a time");
           p=1;
          rec.setFill(Color.WHITE);
       }
       p++;
    }

    
    @FXML
    private void confirmaction(ActionEvent event) {
        Node node = (Node)event.getSource();
         dialogStage = (Stage) node.getScene().getWindow();
                dialogStage.close();
                System.out.println("Seat no is "+rect);
        // seatnoL.setText(rect);
    }
    
    
}
