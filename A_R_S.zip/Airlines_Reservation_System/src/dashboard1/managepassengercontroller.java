package dashboard1;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXTextField;
import commonpackage.ConnectionUtil;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 *
 * @author mahesh
 */
public class managepassengercontroller implements Initializable {
    
    
      private ComboBox select1;
    @FXML
    private JFXButton search;
    @FXML
    private TableColumn<table, String> fname;
    @FXML
    private TableColumn<table, String> lname;
    @FXML
    private TableColumn<table, String> email;
    @FXML
    private TableColumn<table, String> mobileno;
    @FXML
    private TableColumn<table, String> gender;
    @FXML
    private TableColumn<table, String> date;
    @FXML
    private TableView<table> table12;
     
     private ObservableList<table> data   ; 
    private ConnectionUtil dc;
    @FXML
    private TableColumn<table, String> id;
   
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        dc=new ConnectionUtil();
        
        
    }    

    @FXML
    private void showf(ActionEvent event) {
          Connection conn=dc.connectdb();
          data = FXCollections.observableArrayList();
           try{ 
            //  String s12=datepik.getValue();
           ResultSet rs=conn.createStatement().executeQuery("select * from customerdetail ");
                 
           System.out.print(rs);
          
            //System.out.println(rs);
           // rs.next();
            while(rs.next())
            {
                data.add(new table(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7)));
            }
           
            
                    }
          catch (SQLException ex) {
          System.out.println(ex);
          }
           id.setCellValueFactory(new PropertyValueFactory<>("id"));
            fname.setCellValueFactory(new PropertyValueFactory<>("fname"));
             lname.setCellValueFactory(new PropertyValueFactory<>("lname"));
            email.setCellValueFactory(new PropertyValueFactory<>("email"));
             mobileno.setCellValueFactory(new PropertyValueFactory<>("mobileno"));
            gender.setCellValueFactory(new PropertyValueFactory<>("gender"));
             date.setCellValueFactory(new PropertyValueFactory<>("date"));
           // departuret.setCellValueFactory(new PropertyValueFactory<>("departuret"));
           //  date.setCellValueFactory(new PropertyValueFactory<>("date"));
           // name.setCellValueFactory(new PropertyValueFactory<>("name"));
          
           table12.setItems(data);
           System.out.println(table12);
    }
        
    }
    

