/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dashboard1;

import UserLogin.FXMLController;
import animatefx.animation.Bounce;
import animatefx.animation.Shake;
import animatefx.animation.ZoomIn;
import com.jfoenix.controls.JFXButton;
import commonpackage.ConnectionUtil;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Duration;
import static UserLogin.FXMLController.myid;
import static dashboard2.FXMLDocumentController.User;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author mahesh
 */
public class FXMLDocumentController implements Initializable {
    
     static public int User =UserLogin.FXMLController.retid();
           Stage dialogStage = new Stage();
       int flag=0;
        Connection connection = null;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;
    
    private JFXButton logoutf;
    @FXML 
    private AnchorPane anchor1;
    
    
    @FXML
    private JFXButton managepassengerb;
    @FXML
    private JFXButton addflightb;
    @FXML
    private JFXButton updatedetailsb;
    //@FXML
   // private JFXButton cancleflightsb;
    @FXML
    private JFXButton viewbookingb;
    @FXML
    private JFXButton feedbackb;
    @FXML
    private Label nametag;
    @FXML
    private AnchorPane box1;
    @FXML
    private AnchorPane box2;
    @FXML
    private AnchorPane box3;
    @FXML
    private AnchorPane anch;
    @FXML
    private JFXButton dashboard1;
    @FXML
    private JFXButton query;
    @FXML
    private JFXButton manageflight;
    @FXML
    private Label nameid;
     private String name;
 
    @Override
    public void initialize(URL url, ResourceBundle rb) {
         name=FXMLController.retname();
            nameid.setText(name);
/*
    try {
                String Sql1="select * from admindetail where id ='"+User+"' ";
        preparedStatement = connection.prepareStatement(Sql1);
           resultSet = preparedStatement.executeQuery();
           if(resultSet.next())
        {
            String fname=resultSet.getString("firstname");
            String lname=resultSet.getString("lastname");
            nametag.setText(fname+" "+lname);
                    }
    } catch (SQLException ex) {
        Logger.getLogger(dashboard2.FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
    }
  */      
         TranslateTransition t = new TranslateTransition();
      t.setDuration(Duration.seconds(1));
      //t.setAutoReverse(true);
      t.setCycleCount(3);
      t.setToX(670); t.setNode(box1); t.play();
      
       TranslateTransition t1 = new TranslateTransition();
      t1.setDuration(Duration.seconds(1));
     // t1.setAutoReverse(true);
      t1.setCycleCount(3);
    //  t1.setToX(-300);
      t1.setNode(box2); t1.play();
      
       TranslateTransition t2 = new TranslateTransition();
      t2.setDuration(Duration.seconds(1));
     // t1.setAutoReverse(true);
      t2.setCycleCount(3);
      t2.setToX(-670); t2.setNode(box3); t2.play();
        // TODO
    }    
    
    @FXML private void dashboard(ActionEvent event) throws IOException
    {
    AnchorPane pane=FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
   anch.getChildren().setAll(pane);
   new ZoomIn(anch).play();
     new Shake(dashboard1).play();
    
    };
    
    @FXML private void managepassenger(ActionEvent event) throws IOException
    { 
    AnchorPane pane1=FXMLLoader.load(getClass().getResource("managepassengerf.fxml"));
    anchor1.getChildren().setAll(pane1);
  new ZoomIn(anchor1).play();
     new Shake(managepassengerb).play();
    
    };
    
     @FXML private void addflightf(ActionEvent event) throws IOException
    {
    AnchorPane pane1=FXMLLoader.load(getClass().getResource("/add_flight/FXMLDocument.fxml"));
    anchor1.getChildren().setAll(pane1);
   new ZoomIn(anchor1).play();
     new Shake(addflightb).play();
    
    };
    
      @FXML private void updatedetailsf(ActionEvent event) throws IOException
    {
    AnchorPane pane1=FXMLLoader.load(getClass().getResource("/update_flight/FXMLDocument.fxml"));
    anchor1.getChildren().setAll(pane1);
   
    new ZoomIn(anchor1).play();
     new Shake(updatedetailsb).play();
    };
      
      
    /*   @FXML private void cancleflightsf(ActionEvent event) throws IOException
    {
    AnchorPane pane1=FXMLLoader.load(getClass().getResource("cancleflight.fxml"));
    anchor1.getChildren().setAll(pane1);
    };*/
       
      @FXML private void viewbookingf(ActionEvent event) throws IOException
    {
    AnchorPane pane1=FXMLLoader.load(getClass().getResource("/AdminBookingDetail/FXML.fxml"));
    anchor1.getChildren().setAll(pane1);
    
    new ZoomIn(anchor1).play();
     new Shake(viewbookingb).play();
    };
      
       /*private void init() {
        nameL.setText("Hello World!");
       // daten.setText("AnotherTest");
    }*/
    
     
      @FXML private void feedbackf(ActionEvent event) throws IOException
    {
    AnchorPane pane1=FXMLLoader.load(getClass().getResource("/admin_feedback/FXMLDocument.fxml"));
    anchor1.getChildren().setAll(pane1);
    new ZoomIn(anchor1).play();
     new Shake(feedbackb).play();
    };
      
      
      @FXML
      
      private void logoutf(ActionEvent event) throws IOException {
       Node node = (Node)event.getSource();
                dialogStage = (Stage) node.getScene().getWindow();
                dialogStage.close();
               
               Scene scene = new Scene(FXMLLoader.load(getClass().getResource("/home/FXMLDocument.fxml")));
                
                dialogStage.setScene(scene);
        
                dialogStage.show();
               //  dialogStage.close();
               
                
                
    }
      //for recept change purpose

    @FXML
    private void queryf(ActionEvent event) throws IOException {
         AnchorPane pane1=FXMLLoader.load(getClass().getResource("/queries/FXMLDocument.fxml"));
        anchor1.getChildren().setAll(pane1);
    new ZoomIn(anchor1).play();
     new Shake(query).play();
    }

    @FXML
    private void manageflightf(ActionEvent event) throws IOException {
        AnchorPane pane1=FXMLLoader.load(getClass().getResource("/view_flights/FXMLDocument.fxml"));
        anchor1.getChildren().setAll(pane1);
    new ZoomIn(anchor1).play();
     new Shake(manageflight).play();
    }
      
      
      
      
}
