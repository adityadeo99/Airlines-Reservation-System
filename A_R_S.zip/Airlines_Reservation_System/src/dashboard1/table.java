/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dashboard1;


import search_flight.*;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.ObservableList;

/**
 *
 * @author Akshay
 */
public class table {
 private final StringProperty id;
 private final StringProperty fname;
 private final StringProperty lname;
private final StringProperty email;
private final StringProperty mobileno;
private final StringProperty gender;
private final StringProperty date;


    public table(String id, String name,String source3, String destination3,String type, String arrivalt,String departuret) {
        this.id = new SimpleStringProperty(id);
        this.fname = new SimpleStringProperty(name);
        this.lname = new SimpleStringProperty(source3);
        this.email = new SimpleStringProperty(destination3);
        this.mobileno = new SimpleStringProperty(type);
        this.gender = new SimpleStringProperty(arrivalt);
        this.date = new SimpleStringProperty(departuret);
        
    }

    public String getdate() {
        return date.get();
    }
      public void setdate(String value) {
         date.set(value);   
    }
  public StringProperty dateProperty(){    return date;} 

    public String getid() {
        return id.get();
    }

      public void setid(String value) {
         id.set(value);   
    }
  public StringProperty idProperty(){    return id;} 
   
  public String getfname() {
        return fname.get();
    }
 public void setfname(String value) {
         fname.set(value);   
    }
  public StringProperty fnameProperty(){    return fname;}
  
    public String getlname() {
        return lname.get();
    }
 public void setlname(String value) {
         lname.set(value);   
    }
  public StringProperty lnameProperty(){    return lname;} 
    
    
    
    public String getemail() {
        return email.get();
    }
     public void setemail(String value) {
         email.set(value);   
    }
  public StringProperty emailProperty(){    return email;} 

    
    public String getmobileno() {
        return mobileno.get();
    }
    
     public void setmobileno(String value) {
         mobileno.set(value);   
    }
  public StringProperty mobilenoProperty(){    return mobileno;} 

    public String getgender() {
        return gender.get();
    }
     public void setgender(String value) {
         gender.set(value);   
    }
  public StringProperty genderProperty(){    return gender;} 

}