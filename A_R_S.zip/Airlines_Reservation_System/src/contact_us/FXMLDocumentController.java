/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package contact_us;

import com.jfoenix.controls.JFXTextArea;
import com.jfoenix.controls.JFXTextField;
import commonpackage.ConnectionUtil;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author Aditya Deo
 */
public class FXMLDocumentController implements Initializable {
    
    private Label label;
    @FXML
    private JFXTextField first;
    @FXML
    private JFXTextField mail;
    @FXML
    private JFXTextArea stmt;
    @FXML
    private JFXTextField last;
    
    
    Connection connection = null;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;
    @FXML
    private AnchorPane anchor1;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void submitDone(ActionEvent event) throws SQLException, IOException {
         connection = ConnectionUtil.connectdb();
         
         int i1 = first.getText().length();
         int i2 = last.getText().length();
         int i3 = mail.getText().length();
         int i4 = stmt.getText().length();
         
         if(i1>0&&i2>0&&i3>0&&i4>0){
         String sql="insert into contactus values('"+first.getText()+"','"+last.getText()+"','"+mail.getText()+"','"+stmt.getText()+"')";
          preparedStatement = connection.prepareStatement(sql);
        preparedStatement.executeUpdate();
         
        JFrame f; 
                    f=new JFrame(); 
                                 JOptionPane.showMessageDialog(f," Your Query Has Been Submitted !!!","Alert",JOptionPane.OK_OPTION);        
                                 
         AnchorPane pane=FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
    anchor1.getChildren().setAll(pane);                        
         }
         else{
              JFrame f = new JFrame(); 
               JOptionPane.showMessageDialog(f,"Please Enter All the Details Before Submitting","Alert",JOptionPane.INFORMATION_MESSAGE);        
         }
    }
    
}
