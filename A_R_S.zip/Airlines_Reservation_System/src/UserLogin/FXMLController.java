/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UserLogin;

import animatefx.animation.*;
import com.jfoenix.controls.JFXButton;
import home.ConnectionUtil;
import static java.awt.Color.red;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import static javafx.scene.paint.Color.color;
import static javafx.scene.paint.Color.color;
import static javafx.scene.paint.Color.color;
import static javafx.scene.paint.Color.color;
import javafx.stage.Stage;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author Akshay
 */
public class FXMLController implements Initializable {

    /**
     * Initializes the controller class.
     */
    public  static int myid;
    public static String nameplate;
     public static String nameplatea;
    int a=0,f0=0;
    
        @FXML
    private TextField username;
           @FXML
    private Label label1;
              @FXML
    private Label label2;
    
    @FXML
    private PasswordField password;
    
       Stage dialogStage = new Stage();
    Scene scene;
    Scene scene1;
    
    Connection connection = null;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;
    @FXML
    private JFXButton user;
    @FXML
    private JFXButton admin;
    @FXML
    private JFXButton loginb;
    @FXML
    private JFXButton registerb;
    @FXML
    private Hyperlink forgetpass;
    @FXML
    private JFXButton autologin;
    @FXML
    private ImageView hide;
    
     public FXMLController() {
        connection = ConnectionUtil.connectdb();
    }
     public static int retid()
                    {
                        return myid;
                    }
     public static String retname()
                    {
                        return nameplate;
                    }
       public static String retnamea()
                    {
                        return nameplatea;
                    }
    
    @FXML
    private void loginf(ActionEvent event) throws IOException { 
        
         new Tada(loginb).play();
    if(a==0)
          {
                    String usern=username.getText();
              String pass=password.getText();
                    String sql = "SELECT * FROM customer WHERE username = ? and password = ? and type=?";
        try{
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, usern);
            preparedStatement.setString(2, pass);
            preparedStatement.setInt(3, a);
            resultSet = preparedStatement.executeQuery();
            if(!resultSet.next()){
                
                if(usern.isEmpty()|| pass.isEmpty())
                {
                     label2.setText("Please enter Username");
                      label1.setText("Please enter password");
                        JFrame f; 
                        f=new JFrame();  
                        JOptionPane.showMessageDialog(f," Username or Password Is Empty ","Alert",JOptionPane.OK_OPTION);        
                }
               
                
            }else{
                    myid=resultSet.getInt(1);
                    //System.out.println(myid);
                    nameplate=resultSet.getString(2);
                   
                               
                
                //infoBox("Login Successfull",null,"Success" );
                Node node = (Node)event.getSource();
                dialogStage = (Stage) node.getScene().getWindow();
                dialogStage.close();
                
                scene = new Scene(FXMLLoader.load(getClass().getResource("/dashboard2/FXMLDocument.fxml")));
                
                
            //   scene = new Scene(FXMLLoader.load(getClass().getResource("/dashboard1/FXMLDocument.fxml")));
                
               
               dialogStage.setScene(scene);
                dialogStage.show();
                    
            }
                        

        }
         
         catch(Exception e){
            e.printStackTrace();
        }
        }
    
    if(a==1)
         {
                    
                    String usern=username.getText();
         String pass=password.getText();
                    String sql = "SELECT * FROM admin WHERE username = ? and password = ? and type=?";
        try{
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, usern);
            preparedStatement.setString(2, pass);
            preparedStatement.setInt(3, a);
            resultSet = preparedStatement.executeQuery();
            if(!resultSet.next()){
                
                if(usern.isEmpty()|| pass.isEmpty())
                {
                     label2.setText("Please enter Username");
                      label1.setText("Please enter password");
                      JFrame f; 
                    f=new JFrame();  
                        JOptionPane.showMessageDialog(f," Username or Password Is Empty ","Alert",JOptionPane.OK_OPTION);    
                }
               
                
            }else{
              
                    myid=resultSet.getInt(1);
                    //System.out.println(myid);
                    nameplate=resultSet.getString(2);
                    
                //infoBox("Login Successfull",null,"Success" );
                Node node = (Node)event.getSource();
                dialogStage = (Stage) node.getScene().getWindow();
                dialogStage.close();
                
               // scene = new Scene(FXMLLoader.load(getClass().getResource("/dashboard2/FXMLDocument.fxml")));
                
                
               scene = new Scene(FXMLLoader.load(getClass().getResource("/dashboard1/FXMLDocument.fxml")));
                
                
               dialogStage.setScene(scene);
                dialogStage.show();
            }
        }
         catch(Exception e){
            e.printStackTrace();
        }
        }
    else if(username.getText()==null && password.getText()==null)
    {
    JFrame f1; 
                    f1=new JFrame();  
                        JOptionPane.showMessageDialog(f1," Something is wrong .","Alert",JOptionPane.YES_OPTION);                     
                
                //infoBox("Login Successfull",null,"Success" );
                Node node = (Node)event.getSource();
                dialogStage = (Stage) node.getScene().getWindow();
                dialogStage.close();
                
                scene = new Scene(FXMLLoader.load(getClass().getResource("/home/FXMLDocument.fxml")));
                
                
               dialogStage.setScene(scene);
                dialogStage.show();
    
    }
       
        
    
    }
     public static void infoBox(String infoMessage, String headerText, String title){
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setContentText(infoMessage);
        alert.setTitle(title);
        alert.setHeaderText(headerText);
        alert.showAndWait();
    }
     
    @FXML
    private void registerf(ActionEvent event) throws IOException {
                     new Tada(registerb).play();

                Node node = (Node)event.getSource();
               // dialogStage = (Stage) node.getScene().getWindow();
                dialogStage.close();
               
                scene = new Scene(FXMLLoader.load(getClass().getResource("/UserRegister/FXML.fxml")));
                
                dialogStage.setScene(scene);
        
                dialogStage.show();
                
                
            //    dialogStage.close();
       
    }
     @FXML
    private void iamuser(ActionEvent event) throws IOException {
        user.setStyle("-fx-background-color:red;");
         admin.setStyle("-fx-background-color:Orange;");
        a=0;
         new Swing(user).play();
       // scene.getStylesheets().add(getClass().getResource("fxml.css").toExternalForm());
//user.getStyleClass().add("toggle-button");
    }
     @FXML
    private void iamadmin(ActionEvent event) throws IOException {
        a=1;
         user.setStyle("-fx-background-color:Orange;");
          admin.setStyle("-fx-background-color:red;");
         new Swing(admin).play();
    }
    @FXML
    private void forgetf(ActionEvent event) throws IOException {
          Node node = (Node)event.getSource();
              //  dialogStage = (Stage) node.getScene().getWindow();
              dialogStage.close();
                
               // scene = new Scene(FXMLLoader.load(getClass().getResource("/dashboard2/FXMLDocument.fxml")));
                
                
               scene = new Scene(FXMLLoader.load(getClass().getResource("/Forgetp/FXML.fxml")));
               dialogStage.setScene(scene);
                dialogStage.show();
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void autologinf(ActionEvent event) throws SQLException, IOException {
         String usern="aditya";
              String pass="12345";
                    String sql = "SELECT * FROM customer WHERE username = ? and password = ? and type=?";
        
                      preparedStatement = connection.prepareStatement(sql);
                      preparedStatement.setString(1, usern);
                      preparedStatement.setString(2, pass);
                      preparedStatement.setInt(3, 1);
                      resultSet = preparedStatement.executeQuery();
            
                      
                       Node node = (Node)event.getSource();
                dialogStage = (Stage) node.getScene().getWindow();
                dialogStage.close();
                
                scene = new Scene(FXMLLoader.load(getClass().getResource("/dashboard2/FXMLDocument.fxml")));
                
                
            //   scene = new Scene(FXMLLoader.load(getClass().getResource("/dashboard1/FXMLDocument.fxml")));
                
               
               dialogStage.setScene(scene);
                dialogStage.show();
                    
        
    }
     @FXML
    private void showPD(MouseEvent event) {
        
        if(f0==0)
        {   
            label1.setVisible(true);
            label1.setText(password.getText());
            f0++;
        }else {
                    label1.setVisible(false);
                    f0=0;
        }
    }
    
}
