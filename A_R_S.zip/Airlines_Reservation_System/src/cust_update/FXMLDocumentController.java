/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cust_update;

import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import commonpackage.ConnectionUtil;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import static UserLogin.FXMLController.myid;
import javafx.scene.layout.AnchorPane;

/**
 *
 * @author Aditya Deo
 */
public class FXMLDocumentController implements Initializable {

     static public int User =UserLogin.FXMLController.retid();
       Stage dialogStage = new Stage();
       int flag=0;
        Connection connection = null;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;
    @FXML
    private JFXPasswordField pass1;
    @FXML
    private JFXPasswordField pass2;
    @FXML
    private JFXTextField mobile;
    @FXML
    private JFXTextField mail;
    @FXML
    private AnchorPane anchor1;
    
        
        @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void update(ActionEvent event) throws IOException, SQLException {
        connection = ConnectionUtil.connectdb();
         int Mail=mail.getText().length();
         int Mobile=mobile.getText().length();
         int p1=pass1.getText().length();
         int p2=pass2.getText().length();
         
          if((Mail>0)&&(p1>0&&p2>0)&&(Mobile>0)){
             flag=7;
         }
        else if((Mail>0)&&(p1>0&&p2>0)){
             flag=6;
         }
        else if((Mobile>0)&&(p1>0&&p2>0)){
             flag=5;
         }
        else if((Mobile>0)&&Mail>0){
             flag=4;
         }
        else if(p1>0&&p2>0){
             flag=3;
         }
        else if(Mobile>0){
             flag=2;
         }
        else if(Mail>0){
             flag=1;
         }//else flag =8;
         
          
         String Sql1="select * from customerdetail where id ='"+User+"' ";
          preparedStatement = connection.prepareStatement(Sql1);
           // preparedStatement.setString(1,User);
            resultSet = preparedStatement.executeQuery();
         if(resultSet.next())
         {
            //String u1=resultSet.getString("email");
            switch (flag) {
                case 1:
                    {
                        String sql="update customerdetail set email='"+mail.getText()+"' where id='"+User+"'";
                        Statement smt3=connection.createStatement();
                        int success=smt3.executeUpdate(sql);
                        if(success==1){
                            JFrame f;
                            f=new JFrame();
                            JOptionPane.showMessageDialog(f," Your Email has been Successfully Updated ...","Message",JOptionPane.INFORMATION_MESSAGE);
                        }break;
                    }
                case 2:
                    {
                        String sql="update customerdetail set mobileno='"+mobile.getText()+"' where id='"+User+"'";
                        Statement smt3=connection.createStatement();
                        int success=smt3.executeUpdate(sql);
                        if(success==1){
                            JFrame f;
                            f=new JFrame();
                            JOptionPane.showMessageDialog(f," Your Mobile No. has been Successfully Updated ...","information",JOptionPane.INFORMATION_MESSAGE);
                        }break;
                    }
                case 3:
                    {
                        String p11=pass1.getText();
                        String p22=pass2.getText();
                        if(p11.equals(p22)){
                            String sql="update customer set password='"+pass1.getText()+"' where id='"+User+"'";
                            Statement smt3=connection.createStatement();
                            int success=smt3.executeUpdate(sql);
                            if(success==1){
                                JFrame f;
                                f=new JFrame();
                                JOptionPane.showMessageDialog(f," Your Password has been Successfully Updated ...","information",JOptionPane.INFORMATION_MESSAGE);
                            }
                        }else {
                            JFrame f;
                            f=new JFrame();
                            JOptionPane.showMessageDialog(f," Please Enter Both password Same ...","Alert",JOptionPane.WARNING_MESSAGE);
                        }          break;
                    }
                case 4:
                    {
                        String sql="update customerdetail set mobileno='"+mobile.getText()+"',email='"+mail.getText()+"' where id='"+User+"'";
                        Statement smt3=connection.createStatement();
                        int success=smt3.executeUpdate(sql);
                        if(success==1){
                            JFrame f;
                            f=new JFrame();
                            JOptionPane.showMessageDialog(f," Your Mobile No. & Email has been Successfully Updated ...","information",JOptionPane.INFORMATION_MESSAGE);
                        }break;
                    }
                case 5:
                    {
                        String p11=pass1.getText();
                        String p22=pass2.getText();
                        if(p11.equals(p22)){
                            String sql="update customerdetail set mobileno='"+mobile.getText()+"' where id='"+User+"'";
                            Statement smt3=connection.createStatement();
                            String sql1="update customer set password='"+pass1.getText()+"' where id='"+User+"'";
                            Statement smt=connection.createStatement();
                            int success=smt.executeUpdate(sql1);
                            int success1=smt.executeUpdate(sql);
                            if(success==1&&success1==1){
                                JFrame f;
                                f=new JFrame();
                                JOptionPane.showMessageDialog(f," Your Mobile No. & Password has been Successfully Updated ...","information",JOptionPane.INFORMATION_MESSAGE);
                            }
                        } else {
                            JFrame f;
                            f=new JFrame();
                            JOptionPane.showMessageDialog(f," Please Enter Both Password Same ...","Alert",JOptionPane.WARNING_MESSAGE);
                        }          break;
                    }
                case 6:
                    {
                        String p11=pass1.getText();
                        String p22=pass2.getText();
                        if(p11.equals(p22)){
                            String sql="update customerdetail set email='"+mail.getText()+"' where id='"+User+"'";
                            Statement smt3=connection.createStatement();
                            String sql1="update customer set password='"+pass1.getText()+"' where id='"+User+"'";
                            Statement smt=connection.createStatement();
                            int success=smt.executeUpdate(sql1);
                            int success1=smt.executeUpdate(sql);
                            if(success==1&&success1==1){
                                JFrame f;
                                f=new JFrame();
                                JOptionPane.showMessageDialog(f," Your Mail & Password has been Successfully Updated ...","information",JOptionPane.INFORMATION_MESSAGE);
                            }
                        } else {
                            JFrame f;
                            f=new JFrame();
                            JOptionPane.showMessageDialog(f," Please Enter Both Password Same ...","Alert",JOptionPane.WARNING_MESSAGE);
                        }          break;
                    }
                case 7:
                    {
                        String p11=pass1.getText();
                        String p22=pass2.getText();
                        if(p11.equals(p22)){
                            String sql="update customerdetail set mobileno='"+mobile.getText()+"',email='"+mail.getText()+"' where id='"+User+"'";
                            Statement smt3=connection.createStatement();
                            String sql1="update customer set password='"+pass1.getText()+"' where id='"+User+"'";
                            Statement smt=connection.createStatement();
                            int success=smt.executeUpdate(sql1);
                            int success1=smt.executeUpdate(sql);
                            if(success==1&&success1==1){
                                JFrame f;
                                f=new JFrame();
                                JOptionPane.showMessageDialog(f," Every Deatils has been Successfully Updated ...","information",JOptionPane.INFORMATION_MESSAGE);
                            }
                        }else {
                            JFrame f;
                            f=new JFrame();
                            JOptionPane.showMessageDialog(f," Please Enter Both Password Same ...","Alert",JOptionPane.WARNING_MESSAGE);
                        }          break;
                    }
               /* case 8:
                    JFrame f = new JFrame();
                    JOptionPane.showMessageDialog(f,"Enter Any Details to Update","Alert",JOptionPane.INFORMATION_MESSAGE);
                    break;*/
                default:
                    break;
            }
             
         AnchorPane pane=FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
        anchor1.getChildren().setAll(pane);
         }      
                
    }
    
}
