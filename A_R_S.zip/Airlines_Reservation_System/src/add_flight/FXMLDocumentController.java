/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package add_flight;

import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXTimePicker;
import commonpackage.ConnectionUtil;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author Aditya Deo
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML
    
    private JFXComboBox source;
    
    @FXML
    
    private JFXComboBox type;
     @FXML
    
    private JFXComboBox namef;
    
    @FXML
    private JFXComboBox destination;
    
    private Label label;
    
    @FXML
    private TextField idf;
    
    @FXML
    private TextField charges;

    @FXML
    private JFXTimePicker sourcetime;

    @FXML
    private JFXTimePicker destinationtime;

  
    
     Connection connection = null;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;
    
      ObservableList<String> source1 =FXCollections.observableArrayList("Mumbai","Bangalore","Chennai","Pune","Hyderabad","New Delhi");
      ObservableList<String> destination1 =FXCollections.observableArrayList("Mumbai","Bangalore","Chennai","Pune","Hyderabad","New Delhi");
      ObservableList<String> type1 =FXCollections.observableArrayList(" travel classes","First Class","Economy Class");
      ObservableList<String> name1 =FXCollections.observableArrayList("IndiGo","JetLite","SpiceJet","GoAir","Air india");
   // private JFXDatePicker date123;
    @FXML
    private AnchorPane anchor1;
    

     @FXML
    private void addf(ActionEvent event) throws SQLException, IOException {
         connection = ConnectionUtil.connectdb();
         
         
          String sql = "insert into fligtdetail values("+null+",'"+namef.getValue()+"','"+source.getValue()+"','"
                 +destination.getValue()+"','"+sourcetime.getValue()+"','"+destinationtime.getValue()+"','"+type.getValue()+"',"+charges.getText()+")";
           System.out.println(sql);  
        preparedStatement = connection.prepareStatement(sql);
        preparedStatement.executeUpdate();
         JFrame f; 
                    f=new JFrame(); 
                                 JOptionPane.showMessageDialog(f," Add  Flight Successfully .","Alert",JOptionPane.WARNING_MESSAGE);                     
                                 
                                          AnchorPane pane=FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
    anchor1.getChildren().setAll(pane);
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
         source.setItems(source1);
        
        destination.setItems(destination1);
        
        type.setItems(type1);
        namef.setItems(name1);
    }    
    
}
