/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package queries;

import commonpackage.ConnectionUtil;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

/**
 *
 * @author Aditya Deo
 */
public class FXMLDocumentController implements Initializable {
    
    private Label label;
    @FXML
    private TableColumn<table,String> fname;
    @FXML
    private TableColumn<table,String> lname;
    @FXML
    private TableColumn<table,String> email;
    @FXML
    private TableColumn<table,String> query;
    @FXML
    private TableView<table> table12;
     private ObservableList<table> data   ; 
    static public int trueid =UserLogin.FXMLController.retid();
       private ConnectionUtil dc;
       
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        
        
         dc=new ConnectionUtil();
         Connection conn=dc.connectdb();
          data = FXCollections.observableArrayList();
           try{ 
            // String s12=datepik.getValue();
           ResultSet rs=conn.createStatement().executeQuery("select * from contactus");
                 
           System.out.print(rs);
          
            //System.out.println(rs);
           // rs.next();
            while(rs.next())
            {
                data.add(new table(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4)));
            }
           
            
                    }
          catch (SQLException ex) {
          System.out.println(ex);
          }
           fname.setCellValueFactory(new PropertyValueFactory<>("fname"));
            lname.setCellValueFactory(new PropertyValueFactory<>("lname"));
             email.setCellValueFactory(new PropertyValueFactory<>("email"));
            query.setCellValueFactory(new PropertyValueFactory<>("query"));
              table12.setItems(data);
           System.out.println(table12);
        
        
        
        
    }    
    }    
    
