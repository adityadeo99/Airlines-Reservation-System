/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package queries;

import admin_feedback.*;
import cancel_flight.*;
import CustomerBookingDetail.*;
import CustomerBookingDetail.*;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.ObservableList;

/**
 *
 * @author Akshay
 */
public class table {
 private final StringProperty fname;
 private final StringProperty lname;
 private final StringProperty email;
private final StringProperty query;;

    public table(String id, String name,String source3, String destination3) {
        this.fname = new SimpleStringProperty(id);
        this.lname = new SimpleStringProperty(name);
        this.email = new SimpleStringProperty(source3);
        this.query = new SimpleStringProperty(destination3);
            }
public String getfname() {
        return fname.get();
    }
 public void setfname(String value) {
         fname.set(value);   
    }
  public StringProperty fnameProperty(){    return fname;} 

    
    public String getlname() {
        return lname.get();
    }
      public void setlname(String value) {
         lname.set(value);   
    }
  public StringProperty lnameProperty(){    return lname;} 

    public String getemail() {
        return email.get();
    }

      public void setemail(String value) {
         email.set(value);   
    }
  public StringProperty emailProperty(){    return email;} 
  
  
  public String getquery() {
        return query.get();
    }

      public void setquery(String value) {
         query.set(value);   
    }
  public StringProperty queryProperty(){    return query;} 
  
  
}