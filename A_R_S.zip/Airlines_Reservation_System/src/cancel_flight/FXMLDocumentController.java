/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cancel_flight;

import com.jfoenix.controls.JFXTextField;
import commonpackage.ConnectionUtil;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author Aditya Deo
 */
public class FXMLDocumentController implements Initializable {
    
    private Label label;
    @FXML
    private TableView<table> table12;
    @FXML
    private TableColumn<table,String> id;
    @FXML
    private TableColumn<table,String> fname;
    @FXML
    private TableColumn<table,String> source3;
    @FXML
    private TableColumn<table,String> destination3;
    @FXML
    private TableColumn<table,String> departuret;
    @FXML
    private TableColumn<table,String> price;
    @FXML
    private TableColumn<table,String> type;
    @FXML
    private TableColumn<table,String> date;
    
      private ObservableList<table> data   ; 
    private ConnectionUtil dc;
    
    @FXML
    private JFXTextField fidno;
     static public int trueflid =CustomerBookingDetail.FXMLController.retflid();
    static public int trueid ;
    @FXML
    private AnchorPane dashboard;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
           dc=new ConnectionUtil();
         Connection conn=dc.connectdb();
         trueid =UserLogin.FXMLController.retid();
          data = FXCollections.observableArrayList();
           try{ 
            // String s12=datepik.getValue();
           ResultSet rs=conn.createStatement().executeQuery("select * from bookingdetails where userid="+trueid);
                 
           System.out.print(rs);
          
            //System.out.println(rs);
           // rs.next();
            while(rs.next())
            {
                data.add(new table(rs.getString(2),rs.getString(10),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(7),rs.getString(8)));
            }
           
            
                    }
          catch (SQLException ex) {
          System.out.println(ex);
          }
           id.setCellValueFactory(new PropertyValueFactory<>("id"));
            fname.setCellValueFactory(new PropertyValueFactory<>("name"));
             source3.setCellValueFactory(new PropertyValueFactory<>("source3"));
            destination3.setCellValueFactory(new PropertyValueFactory<>("destination3"));
             type.setCellValueFactory(new PropertyValueFactory<>("type"));
            date.setCellValueFactory(new PropertyValueFactory<>("date"));
             price.setCellValueFactory(new PropertyValueFactory<>("price"));
            departuret.setCellValueFactory(new PropertyValueFactory<>("departuret"));
           //  date.setCellValueFactory(new PropertyValueFactory<>("date"));
           // name.setCellValueFactory(new PropertyValueFactory<>("name"));
          
           table12.setItems(data);
           System.out.println(table12);
    }

    @FXML
    private void cancelf(ActionEvent event) throws SQLException, IOException  {
      Connection conn=dc.connectdb();
     //   fidno.getText();
        Connection conn1=dc.connectdb();
           try{ 
           String sql="DELETE FROM `bookingdetails` WHERE flightid="+fidno.getText();
           conn1.createStatement().executeUpdate(sql);
                 
           
          JFrame f; 
                      f=new JFrame();  
                    JOptionPane.showMessageDialog(f,"FLight cancel sucessfully ","Notification",JOptionPane.YES_NO_CANCEL_OPTION);                     
        
                    JFrame f1; 
                    f1=new JFrame();  
                    JOptionPane.showMessageDialog(f,"Your refund send to your account in 24 hour","Notification",JOptionPane.YES_NO_CANCEL_OPTION);
            
                        
       AnchorPane pane = FXMLLoader.load(getClass().getResource("/cancel_flight/FXMLDocument.fxml"));
        dashboard.getChildren().setAll(pane);
                    }
          catch (SQLException ex) {
          System.out.println(ex);
          }
         
                                         
                
    }
        
    }    
    

