/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package faqs;

import java.net.URL;
import java.security.Provider.Service;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;

/**
 *
 * @author Aditya Deo
 */
public class FXMLDocumentController implements Initializable {
    
    private Label label;
    @FXML
    private ImageView img;
    @FXML
    private Label l11;
    @FXML
    private Label l33;
    @FXML
    private Label l22;
    
    int f0,f1,f2;
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        l11.setVisible(false);
        l22.setVisible(false);
        l33.setVisible(false);
        f0=f1=f2=0;
        
    }    

    @FXML
    private void label1(MouseEvent event) {
        if(f0==0)
        {
            l11.setVisible(true);
            f0++;
        }else {
                    l11.setVisible(false);
                    f0=0;
        }
    }

    @FXML
    private void label2(MouseEvent event) {
         if(f1==0)
        {
            l22.setVisible(true);
            f1++;
        }else {
                    l22.setVisible(false);
                    f1=0;
        }
    }

    @FXML
    private void label3(MouseEvent event) {
        if(f2==0)
        {
            l33.setVisible(true);
            f2++;
        }else {
                    l33.setVisible(false);
                    f2=0;
        }
    }
    
}
