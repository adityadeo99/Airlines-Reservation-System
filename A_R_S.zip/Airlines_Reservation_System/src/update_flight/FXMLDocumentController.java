/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package update_flight;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import com.jfoenix.controls.JFXTextField;
import com.jfoenix.controls.JFXTimePicker;
import commonpackage.ConnectionUtil;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalTime;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author Aditya Deo
 */
public class FXMLDocumentController implements Initializable {
    
         Connection connection = null;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;
    
    ObservableList<String> source111 =FXCollections.observableArrayList("Mumbai","Bangalore","Chennai","Pune","Hyderabad","New Delhi");
    ObservableList<String> destination111 =FXCollections.observableArrayList("Mumbai","Bangalore","Chennai","Pune","Hyderabad","New Delhi");
    ObservableList<String> type111 =FXCollections.observableArrayList(" travel classes","First Class","Economy Class");
    ObservableList<String> name111 =FXCollections.observableArrayList("IndiGo","JetLite","SpiceJet","GoAir","Air india");
    
    @FXML
    private JFXTimePicker sourceT;
    @FXML
    private JFXTimePicker destinationT;
    @FXML
    private JFXButton updatef;
    @FXML
    private JFXButton deletef;
    @FXML
    private JFXButton searchf;
    @FXML
    private JFXTextField id1;
    @FXML
    private JFXTextField charges;
    @FXML
    private JFXComboBox<String> name1;
    @FXML
    private Label id2;
    @FXML
    private JFXComboBox<String> sourcee1;
    @FXML
    private JFXComboBox<String> type1;
    @FXML
    private JFXComboBox<String> destination1;
    @FXML
    private AnchorPane anchor1;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        name1.setItems(name111);
        sourcee1.setItems(source111);
        destination1.setItems(destination111);
        type1.setItems(type111);
    }    

    @FXML
    private void updateflight(ActionEvent event) throws IOException, SQLException {
         connection = ConnectionUtil.connectdb();
         String getid = id1.getText();
         
          String Sql1="select * from fligtdetail where flightid ='"+getid+"' ";
          preparedStatement = connection.prepareStatement(Sql1);
          resultSet = preparedStatement.executeQuery();
         while(resultSet.next()){
              String sql="update fligtdetail set nameflight='"+name1.getValue()+"',source='"+sourcee1.getValue()+"',destination='"+destination1.getValue()+"'"
                      + ",type='"+type1.getValue()+"',takeuptime='"+sourceT.getValue()+"',landingtime='"+destinationT.getValue()+"',charges='"+charges.getText()+"' "
                      + "where flightid ='"+getid+"' ";
                Statement smt3=connection.createStatement();

                       int success=smt3.executeUpdate(sql);
                       if(success==1){
                           JFrame f=new JFrame(); 
                                 JOptionPane.showMessageDialog(f,"Flight details succesfully updated...","Alert",JOptionPane.OK_OPTION);  
                       }
         }                     
                                 
         AnchorPane pane=FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
         anchor1.getChildren().setAll(pane);
    }

    @FXML
    private void deleteflight(ActionEvent event) throws IOException, SQLException {
         connection = ConnectionUtil.connectdb();
         String getid = id1.getText();
         
          String Sql1="select * from fligtdetail where flightid ='"+getid+"' ";
          preparedStatement = connection.prepareStatement(Sql1);
          resultSet = preparedStatement.executeQuery();
         while(resultSet.next()){
              String sql = "DELETE from fligtdetail where flightid='"+getid+"'   ";
                Statement smt3=connection.createStatement();

                       int success=smt3.executeUpdate(sql);
                       if(success==1){
                    JFrame f=new JFrame(); 
         JOptionPane.showMessageDialog(f," Deleted  Flight Successfully .","Alert",JOptionPane.INFORMATION_MESSAGE); 
         }     
         }
         
         AnchorPane pane=FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
         anchor1.getChildren().setAll(pane);
    }

    @FXML
    private void searchflight(ActionEvent event) throws SQLException {
         connection = ConnectionUtil.connectdb();
         String getid = id1.getText();
         
          String Sql1="select * from fligtdetail where flightid ='"+getid+"' ";
          preparedStatement = connection.prepareStatement(Sql1);
            resultSet = preparedStatement.executeQuery();
         while(resultSet.next()){
             String idno=resultSet.getString(1);
             if(idno.equals(getid)){
             name1.setValue(resultSet.getString(2));
             sourcee1.setValue(resultSet.getString(3));
             destination1.setValue(resultSet.getString(4));
             type1.setValue(resultSet.getString(7));
             id2.setText(getid);
             charges.setText(resultSet.getString(8));
             sourceT.setValue(LocalTime.parse(resultSet.getString(5)));
             destinationT.setValue(LocalTime.parse(resultSet.getString(6)));
            }else{
                      JFrame f=new JFrame(); 
                       JOptionPane.showMessageDialog(f,"Flights does not exists...","Alert",JOptionPane.OK_OPTION);  
                 }
         }
    }
    
    }
