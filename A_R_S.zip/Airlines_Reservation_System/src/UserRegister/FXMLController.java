/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UserRegister;


import animatefx.animation.Tada;
import com.jfoenix.controls.JFXButton;
import commonpackage.ConnectionUtil;
import java.io.IOException;
import java.net.URL;
import java.util.Random;
import javafx.scene.control.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author Akshay
 */
public class FXMLController implements Initializable {

    /**
     * Initializes the controller class.
     * 
     */
    
   
      @FXML
    private TextField firstnameT;

    @FXML
    private TextField lastnameT;

    @FXML
    private TextField emailT;

    @FXML
    private PasswordField confirmT;

    @FXML
    private TextField mobilenoT;
    

    @FXML
    private ComboBox Gender;

    
    @FXML
    private CheckBox makemeadmin;
    
    @FXML
    private DatePicker DOBb;

    @FXML
    private TextField usernameT;
    
     ObservableList<String> genderlist =FXCollections.observableArrayList("Male","Female","Other");
       ObservableList<String> countrylist =Stream.of(Locale.getISOCountries())
        .map(locales -> new Locale("", locales))
        .map(Locale::getDisplayCountry)
        .collect(Collectors.toCollection(FXCollections::observableArrayList));
       
        ObservableList<String> statelist =FXCollections.observableArrayList("Andhra Pradesh","Arunachal Pradesh","Assam","Bihar","Chhattisgarh","Goa","Gujarat","Haryana","Himachal Pradesh","Jammu and Kashmir","Jharkhand","Karnataka","Kerala","Madhya Pradesh","Maharashtra","Manipur","Meghalaya","Mizoram","Nagaland","Odisha","Punjab","Rajasthan","Sikkim","Tamil Nadu","Telangana","Tripura","Uttar Pradesh","Uttarakhand","West Bengal","Andaman and Nicobar","Chandigarh","Dadra and Nagar Haveli","Daman and Diu","Lakshadweep","Delhi","Puducherry");
       
Stage dialogStage = new Stage();
    Scene scene;
    Scene scene1;

private int i;
     
    private AnchorPane anchor1;
    
    Connection connection = null;
    PreparedStatement preparedStatement = null;
    ResultSet resultSet = null;
    @FXML
    private TextField securityT;
    @FXML
    private JFXButton registerb1;
    @FXML
    private PasswordField confirmT1;
     
    
    
    
    @FXML
    
      public void loginAction(ActionEvent event) throws IOException{
           Node node = (Node)event.getSource();
                dialogStage = (Stage) node.getScene().getWindow();
                dialogStage.close();
               
               scene = new Scene(FXMLLoader.load(getClass().getResource("/home/FXMLDocument.fxml")));
                
               dialogStage.setScene(scene);
                dialogStage.show();
                dialogStage.close();
          
      }
       int id=105;
    @FXML
        public void registerf(ActionEvent event) throws IOException, SQLException{
              new Tada(registerb1).play();
              
            Random dice=new Random();
            int Rid=50+dice.nextInt(50);
            
           connection = ConnectionUtil.connectdb();
           String key = securityT.getText();
           String pass=confirmT.getText();
           String pass1=confirmT1.getText();
           
              String key1="Flyhigh@123";
            
              int a1 = firstnameT.getText().length();
              int a2 = lastnameT.getText().length();
              int a3 = emailT.getText().length();
              int a4 = mobilenoT.getText().length();
              //LocalDate a6 = DOBb.getValue();
              int a7 = usernameT.getText().length();
              int a8 = confirmT.getText().length();
              int a5 = confirmT1.getText().length();
              
           int flag=0;
           
         if(makemeadmin.isSelected()){
             if(key1.equals(key)){
                        flag=1;
             }else {
                 flag=2;
             }
        }else if(!makemeadmin.isSelected()){
            flag=0;
        }
         
         System.out.println(key);
        System.out.println(flag);
            
        if(a1>0&&a2>0&&a3>0&&a4>0&&a5>0&&a7>0&&a8>0){
          switch (flag) {
              case 1:
                  {
                      id++;
                      // String sql = "insert into detail values("+100+",'"+firstnameT.getText()+"',"+"'"+lastnameT.getText()+"',"+"'"+emailT.getText()+"',"+mobilenoT.getText()+",'"+Gender.getValue()+"',"+DOBb.getValue()+",'"+country.getValue()+"','"+state.getValue()+"','"+addressT.getText()+"',"+pincode.getText()+")";
                       if(pass.equals(pass1))
                      {
                      String sql = "insert into admindetail values("+Rid+",'"+firstnameT.getText()+"','"+lastnameT.getText()+"','"
                              +emailT.getText()+"',"+mobilenoT.getText()+",'"+Gender.getValue()+"','"+DOBb.getValue()+"')";
                      // System.out.println(sql);
                      preparedStatement = connection.prepareStatement(sql);
                      preparedStatement.executeUpdate();
                     
                      String sql1 = "insert into admin values("+Rid+",'"+usernameT.getText()+"','"+confirmT.getText()+"','"+flag+"')";
                      // System.out.println(sql1);
                      preparedStatement = connection.prepareStatement(sql1);
                      preparedStatement.executeUpdate();
                      JFrame f;
                      f=new JFrame();
                        JOptionPane.showMessageDialog(f," Register Successfully As Admin","Alert",JOptionPane.OK_OPTION);
                        
                      }
                       else{
                           JFrame f;
                      f=new JFrame();
                        JOptionPane.showMessageDialog(f,"Both Passwords Doesn't Match. Please enter again","Alert",JOptionPane.OK_OPTION);
                      }
                      
                      
                      break;
                  }
              case 0:
                  {
                      id++;
                      // String sql = "insert into detail values("+100+",'"+firstnameT.getText()+"',"+"'"+lastnameT.getText()+"',"+"'"+emailT.getText()+"',"+mobilenoT.getText()+",'"+Gender.getValue()+"',"+DOBb.getValue()+",'"+country.getValue()+"','"+state.getValue()+"','"+addressT.getText()+"',"+pincode.getText()+")";
                       if(pass.equals(pass1))
                      {
                      String sql = "insert into customerdetail values("+Rid+",'"+firstnameT.getText()+"','"+lastnameT.getText()+"','"
                              +emailT.getText()+"',"+mobilenoT.getText()+",'"+Gender.getValue()+"','"+DOBb.getValue()+"')";
                      System.out.println(sql);
                      preparedStatement = connection.prepareStatement(sql);
                      preparedStatement.executeUpdate();

                      String sql1 = "insert into customer values("+Rid+",'"+usernameT.getText()+"','"+confirmT.getText()+"','"+flag+"')";
                      System.out.println(sql1);
                      preparedStatement = connection.prepareStatement(sql1);
                      preparedStatement.executeUpdate();
                       JFrame f;
                      f=new JFrame();
                      JOptionPane.showMessageDialog(f," Register Successfully As User","Alert",JOptionPane.OK_OPTION);
                      
                       }
                       else{
                           JFrame f;
                      f=new JFrame();
                        JOptionPane.showMessageDialog(f,"Both Passwords Doesn't Match. Please enter again","Alert",JOptionPane.OK_OPTION);
                      }
                       
                                          
                      break;
                  }
              case 2:
                  {
                      JFrame f;
                      f=new JFrame();
                      JOptionPane.showMessageDialog(f,"Enter Security Key to be an Admin !!!","Alert",JOptionPane.WARNING_MESSAGE);
                      break;
                  }
              default:

          }
        }else{
            JFrame f=new JFrame();
                      JOptionPane.showMessageDialog(f,"Enter Details To Get Registered... \nFields cannot be empty !!","Alert",JOptionPane.WARNING_MESSAGE);
        }
      }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
     Gender.setValue("Male");
    Gender.setItems(genderlist);
   //  country.setValue("select country");
   // country.setItems(countrylist);
   // state.setValue("select");
   // state.setItems(statelist);
       
    }    

   
}
