/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Payment;

import BookTicketcustomer.*;
import com.jfoenix.controls.JFXButton;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.stage.Stage;
import BookTicketcustomer.FXMLController;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Label;
import javafx.stage.Modality;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author mahesh
 */
public class PaymentController implements Initializable {
   
    
   
    @FXML
    private JFXButton finish;
     Stage dialogStage = new Stage();
    Scene scene;
    public JFXButton bookf;
    
    
    Stage dialogStage1 = new Stage();
    @FXML
    private JFXTextField amountl;
    @FXML
    private JFXTextField cardno;
    @FXML
    private JFXTextField exp;
    @FXML
    private JFXTextField cvv;
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        amountl.setText("1000");
    }    

    @FXML
    private void finishf(ActionEvent event) {
        //FXMLController.done();
       
        
        
        
            JFrame f1; 
            f1=new JFrame();  
            JOptionPane.showMessageDialog(f1,"Payment Successfully Done...","Alert",JOptionPane.OK_OPTION);                            
              Node node = (Node)event.getSource();
                dialogStage = (Stage) node.getScene().getWindow();
                dialogStage.close();
        }
         
    
                
    

    @FXML
    private void evt(ActionEvent event) {
        
}
    
}