/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AdminBookingDetail;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.ObservableList;

/**
 *
 * @author Akshay
 */
public class table {
 private final StringProperty tid;
 private final StringProperty fid;
 private final StringProperty cid;
private final StringProperty type;
private final StringProperty price;
private final StringProperty date;
private final StringProperty paymentdetail;
//private final StringProperty price;
//private final StringProperty date;

    public table(String tid, String fid,String cid, String type,String price, String date,String paymentdetail) {
        this.tid = new SimpleStringProperty(tid);
        this.fid = new SimpleStringProperty(fid);
        this.cid = new SimpleStringProperty(cid);
        this.type = new SimpleStringProperty(type);
        this.price = new SimpleStringProperty(price);
        this.date = new SimpleStringProperty(date);
        this.paymentdetail = new SimpleStringProperty(paymentdetail);
       // this.price = new SimpleStringProperty(price);
        //this.date=new SimpleStringProperty(date);
    }

    public String getdate() {
        return date.get();
    }
      public void setdate(String value) {
         date.set(value);   
    }
  public StringProperty dateProperty(){    return date;} 

    public String getfid() {
        return fid.get();
    }

      public void setfid(String value) {
         fid.set(value);   
    }
  public StringProperty fidProperty(){    return fid;} 
  
  
   public String gettype() {
        return type.get();
    }

      public void settype(String value) {
         type.set(value);   
    }
  public StringProperty typeProperty(){    return type;} 
  
  
   
   public String gettid() {
        return tid.get();
    }

      public void settid(String value) {
         tid.set(value);   
    }
  public StringProperty tidProperty(){    return tid;} 
   
   public String getcid() {
        return cid.get();
    }

      public void setcid(String value) {
         cid.set(value);   
    }
  public StringProperty cidProperty(){    return cid;} 
   
  public String getprice() {
        return price.get();
    }
 public void setprice(String value) {
         price.set(value);   
    }
  public StringProperty priceProperty(){    return price;}
  
    public String getpaymentdetail() {
        return paymentdetail.get();
    }
 public void setpaymentdetail(String value) {
         paymentdetail.set(value);   
    }
  public StringProperty paymentdetailProperty(){    return paymentdetail;} 
}
    
  