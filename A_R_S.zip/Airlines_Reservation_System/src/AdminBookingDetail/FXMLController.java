/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AdminBookingDetail;

import commonpackage.ConnectionUtil;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
//import ConnectionUtil;

/**
 * FXML Controller class
 *
 * @author Akshay
 * 
 */



public class FXMLController implements Initializable {
    
     public  static int flid;
 static public int trueid =UserLogin.FXMLController.retid();
    /**
     * Initializes the controller class.
     */
    ObservableList<String> selectlist =FXCollections.observableArrayList("Flight Date");

     @FXML
      private ComboBox select1;
    @FXML
    private TableView<table> tablev12;
    @FXML
    private TableColumn<table, String> tid;
    @FXML
    private TableColumn<table, String> fid;
    @FXML
    private TableColumn<table, String> cid;
    @FXML
    private TableColumn<table, String> type;
    @FXML
    private TableColumn<table, String> price;
    @FXML
    private TableColumn<table, String> date;
    @FXML
    private TableColumn<table, String> paymentdetail;
    @FXML
    private DatePicker datepik;
     
    
      private ObservableList<table> data   ; 
    private ConnectionUtil dc;
   
    public static int retflid()
                    {
                        return flid;
                    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
          dc=new ConnectionUtil();
        select1.setValue("Flight Date");
        select1.setItems(selectlist);
        
    }    

    @FXML
    private void searchf(ActionEvent event) {
          Connection conn=dc.connectdb();
          data = FXCollections.observableArrayList();
           try{ 
            //  String s12=datepik.getValue();
           ResultSet rs=conn.createStatement().executeQuery("select * from bookingdetails where date='"+(datepik.getValue())+"' ");
                 
           System.out.print(rs);
          
            //System.out.println(rs);
           // rs.next();
            while(rs.next())
            {  data.add(new table(rs.getString(1),rs.getString(2),rs.getString(10),rs.getString(6),rs.getString(8),rs.getString(9),rs.getString(14)));
            }
            
            
            flid=rs.getInt(2);
            
                    }
          catch (SQLException ex) {
          System.out.println(ex);
          }
           tid.setCellValueFactory(new PropertyValueFactory<>("tid"));
            fid.setCellValueFactory(new PropertyValueFactory<>("fid"));
             cid.setCellValueFactory(new PropertyValueFactory<>("cid"));
            type.setCellValueFactory(new PropertyValueFactory<>("type"));
             price.setCellValueFactory(new PropertyValueFactory<>("price"));
            date.setCellValueFactory(new PropertyValueFactory<>("date"));
             paymentdetail.setCellValueFactory(new PropertyValueFactory<>("paymentdetail"));
          
           tablev12.setItems(data);
           System.out.println(tablev12);
    }
        
    }
    

