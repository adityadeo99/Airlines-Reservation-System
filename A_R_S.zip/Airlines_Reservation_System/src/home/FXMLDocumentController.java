/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package home;

import animatefx.animation.*;
import com.jfoenix.controls.JFXButton;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.util.Duration;

/**
 *
 * @author mahesh
 */
public class FXMLDocumentController implements Initializable {
    
    private Label label3;
   @FXML 
    private AnchorPane anchor1;
   
   Stage dialogStage = new Stage();
    Scene scene;
    Scene scene1;
    @FXML
    private AnchorPane main;
     @FXML
    private JFXButton home;
    @FXML
    private JFXButton search;
    @FXML
    private JFXButton services;
    @FXML
    private JFXButton offer;
    @FXML
    private JFXButton contact;
    @FXML
    private JFXButton about;
    @FXML
    private ImageView airoplane;
    
    /**
     *
     * @param Event
     * @throws java.io.IOException
     */
   
   
    @Override
    public void initialize(URL url, ResourceBundle rb) {
          
        try {
            // TODO
            homef();
        } catch (IOException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InterruptedException ex) {
            Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }   
     @FXML
    public void searchf(ActionEvent Event) throws IOException
    {
                       new ZoomIn(airoplane).setDelay(Duration.seconds(3)).setResetOnFinished(false).play();

          home.setStyle("-fx-background-color:#5C5CFF;");
        services.setStyle("-fx-background-color:#5C5CFF;");
          search.setStyle("-fx-background-color:#0000FF;");
          offer.setStyle("-fx-background-color:#5C5CFF;");
          contact.setStyle("-fx-background-color:#5C5CFF;"); 
          about.setStyle("-fx-background-color:#5C5CFF;");
             AnchorPane pane=FXMLLoader.load(getClass().getResource("/search_flight/FXMLDocument.fxml"));
    anchor1.getChildren().setAll(pane);
     new ZoomIn(anchor1).play();
     new Bounce(search).play();
      
    };
    
    @FXML
     private void homef() throws IOException, InterruptedException{
                        new ZoomIn(airoplane).setDelay(Duration.seconds(3)).setResetOnFinished(false).play();

       home.setStyle("-fx-background-color:#0000FF;");
        search.setStyle("-fx-background-color:#5C5CFF;");
          services.setStyle("-fx-background-color:#5C5CFF;");
          offer.setStyle("-fx-background-color:#5C5CFF;");
          contact.setStyle("-fx-background-color:#5C5CFF;"); 
          about.setStyle("-fx-background-color:#5C5CFF;");
        
     AnchorPane pane1=FXMLLoader.load(getClass().getResource("/UserLogin/FXML.fxml"));
    anchor1.getChildren().setAll(pane1);
         new ZoomIn(anchor1).play();
     new Bounce(home).play();
        };
     
      private void homef(ActionEvent event) throws IOException
    {
               new ZoomIn(airoplane).setDelay(Duration.seconds(3)).setResetOnFinished(false).play();

       home.setStyle("-fx-background-color:#0000FF;");
        search.setStyle("-fx-background-color:#5C5CFF;");
          services.setStyle("-fx-background-color:#5C5CFF;");
          offer.setStyle("-fx-background-color:#5C5CFF;");
          contact.setStyle("-fx-background-color:#5C5CFF;"); 
          about.setStyle("-fx-background-color:#5C5CFF;");
        
       
     AnchorPane pane1=FXMLLoader.load(getClass().getResource("/UserLogin/FXML.fxml"));
    anchor1.getChildren().setAll(pane1);
     new ZoomIn(anchor1).play();
     new Bounce(home).play();
        
    };
      @FXML
       private void serviceF(ActionEvent event) throws IOException
    {
               new ZoomIn(airoplane).setDelay(Duration.seconds(3)).setResetOnFinished(false).play();

         home.setStyle("-fx-background-color:#5C5CFF;");
        search.setStyle("-fx-background-color:#5C5CFF;");
          services.setStyle("-fx-background-color:#0000FF;");
          offer.setStyle("-fx-background-color:#5C5CFF;");
          contact.setStyle("-fx-background-color:#5C5CFF;"); 
          about.setStyle("-fx-background-color:#5C5CFF;");
        

    AnchorPane pane=FXMLLoader.load(getClass().getResource("/services/FXMLDocument.fxml"));
    anchor1.getChildren().setAll(pane);
     new ZoomIn(anchor1).play();
     new Bounce(services).play();
    };
       @FXML
       private void specialofferS(ActionEvent event) throws IOException
    {
                       new ZoomIn(airoplane).setDelay(Duration.seconds(3)).setResetOnFinished(false).play();
          home.setStyle("-fx-background-color:#5C5CFF;");
        search.setStyle("-fx-background-color:#5C5CFF;");
          offer.setStyle("-fx-background-color:#0000FF;");
          services.setStyle("-fx-background-color:#5C5CFF;");
          contact.setStyle("-fx-background-color:#5C5CFF;"); 
          about.setStyle("-fx-background-color:#5C5CFF;");
    AnchorPane pane=FXMLLoader.load(getClass().getResource("/special_offers/FXMLDocument.fxml"));
    anchor1.getChildren().setAll(pane);
     new ZoomIn(anchor1).play();
     new Bounce(offer).play();
    };
       
       @FXML
       private void contactusF(ActionEvent event) throws IOException
    {
                       new ZoomIn(airoplane).setDelay(Duration.seconds(3)).setResetOnFinished(false).play();

          home.setStyle("-fx-background-color:#5C5CFF;");
        search.setStyle("-fx-background-color:#5C5CFF;");
          contact.setStyle("-fx-background-color:#0000FF;");
          offer.setStyle("-fx-background-color:#5C5CFF;");
          services.setStyle("-fx-background-color:#5C5CFF;"); 
          about.setStyle("-fx-background-color:#5C5CFF;");
    AnchorPane pane=FXMLLoader.load(getClass().getResource("/contact_us/FXMLDocument.fxml"));
    anchor1.getChildren().setAll(pane);
     new ZoomIn(anchor1).play();
     new Bounce(contact).play();
    };
    @FXML
       private void aboutusF(ActionEvent event) throws IOException
    {
                       new ZoomIn(airoplane).setDelay(Duration.seconds(3)).setResetOnFinished(false).play();

          home.setStyle("-fx-background-color:#5C5CFF;");
        search.setStyle("-fx-background-color:#5C5CFF;");
          about.setStyle("-fx-background-color:#0000FF;");
          offer.setStyle("-fx-background-color:#5C5CFF;");
          contact.setStyle("-fx-background-color:#5C5CFF;"); 
          services.setStyle("-fx-background-color:#5C5CFF;");
    AnchorPane pane=FXMLLoader.load(getClass().getResource("/about_us/FXMLDocument.fxml"));
    anchor1.getChildren().setAll(pane);
      new ZoomIn(anchor1).play();
     new Bounce(about).play();
    };
       private void loginf(ActionEvent event) throws IOException
    {
                       new ZoomIn(airoplane).setDelay(Duration.seconds(3)).setResetOnFinished(false).play();

         
    AnchorPane pane=FXMLLoader.load(getClass().getResource("/UserLogin/FXML.fxml"));
    anchor1.getChildren().setAll(pane);
    };
        
}
