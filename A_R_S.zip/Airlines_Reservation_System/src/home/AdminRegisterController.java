/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package home;

import java.net.URL;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;

/**
 *
 * @author mahesh
 */
public class AdminRegisterController implements Initializable {
    
   //ObservableList<String> maritalStatusBox =FXCollections.observableArrayList("Akshay","karale");
      ObservableList<String> genderlist =FXCollections.observableArrayList("Male","Female");
       ObservableList<String> countrylist =Stream.of(Locale.getISOCountries())
        .map(locales -> new Locale("", locales))
        .map(Locale::getDisplayCountry)
        .collect(Collectors.toCollection(FXCollections::observableArrayList));
       
        ObservableList<String> statelist =FXCollections.observableArrayList("Andhra Pradesh","Arunachal Pradesh","Assam","Bihar","Chhattisgarh","Goa","Gujarat","Haryana","Himachal Pradesh","Jammu and Kashmir","Jharkhand","Karnataka","Kerala","Madhya Pradesh","Maharashtra","Manipur","Meghalaya","Mizoram","Nagaland","Odisha","Punjab","Rajasthan","Sikkim","Tamil Nadu","Telangana","Tripura","Uttar Pradesh","Uttarakhand","West Bengal","Andaman and Nicobar","Chandigarh","Dadra and Nagar Haveli","Daman and Diu","Lakshadweep","Delhi","Puducherry");
       
      ObservableList<String> qualificationList =FXCollections.observableArrayList("BE","AICTE","AMIE","BBA","BCA","B.Tech","B.Com","BHMS","HSC","SSC","BSC","MBA","MCA");
    /**
     * Initializes the controller class.
     */ 
     @FXML
      private ComboBox gender;
       @FXML
      private ComboBox state;
     
     @FXML
      private ComboBox qualification;
    
 @FXML

ComboBox<String> country = new ComboBox<>(countrylist);

        
        
    @FXML
      @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    gender.setValue("Male");
    gender.setItems(genderlist);
     qualification.setValue("select");
    qualification.setItems(qualificationList);
    country.setValue("select country");
    country.setItems(countrylist);
    state.setValue("select");
    state.setItems(statelist);
    
     


        // TODO
    }    
}
